package com.example.myapplication

import android.app.DatePickerDialog
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.example.myapplication.databinding.ActivityAddEditNoticeBinding
import com.example.myapplication.models.Notice
import java.text.SimpleDateFormat
import java.util.*

class AddEditNoticeActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAddEditNoticeBinding
    private var noticeId: String? = null
    private var isEditMode = false
    private var selectedNoticeDate: Calendar = Calendar.getInstance()
    private var selectedDueDate: Calendar = Calendar.getInstance()
    private val dateFormatter = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddEditNoticeBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        // Check if we're editing an existing notice
        noticeId = intent.getStringExtra("NOTICE_ID")
        isEditMode = noticeId != null
        
        // Setup toolbar
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = if (isEditMode) getString(R.string.edit_notice) else getString(R.string.add_notice)
        
        // Setup date pickers
        setupDatePickers()
        
        // Setup image picker
        setupImagePicker()
        
        // If edit mode, load notice details
        if (isEditMode) {
            loadNoticeDetails()
        } else {
            // Set default dates
            binding.etNoticeDate.setText(dateFormatter.format(selectedNoticeDate.time))
            selectedDueDate.add(Calendar.DAY_OF_MONTH, 7) // Default due date is a week later
            binding.etDueDate.setText(dateFormatter.format(selectedDueDate.time))
        }
        
        // Setup save button
        binding.btnSave.setOnClickListener {
            if (validateInputs()) {
                saveNotice()
            }
        }
    }
    
    private fun setupDatePickers() {
        // Notice date picker
        binding.etNoticeDate.setOnClickListener {
            showDatePicker(selectedNoticeDate) { date ->
                selectedNoticeDate = date
                binding.etNoticeDate.setText(dateFormatter.format(date.time))
            }
        }
        
        // Due date picker
        binding.etDueDate.setOnClickListener {
            showDatePicker(selectedDueDate) { date ->
                selectedDueDate = date
                binding.etDueDate.setText(dateFormatter.format(date.time))
            }
        }
    }
    
    private fun showDatePicker(initialDate: Calendar, onDateSelected: (Calendar) -> Unit) {
        DatePickerDialog(
            this,
            { _, year, month, dayOfMonth ->
                val selectedDate = Calendar.getInstance().apply {
                    set(Calendar.YEAR, year)
                    set(Calendar.MONTH, month)
                    set(Calendar.DAY_OF_MONTH, dayOfMonth)
                }
                onDateSelected(selectedDate)
            },
            initialDate.get(Calendar.YEAR),
            initialDate.get(Calendar.MONTH),
            initialDate.get(Calendar.DAY_OF_MONTH)
        ).show()
    }
    
    private fun setupImagePicker() {
        binding.ivAddImage.setOnClickListener {
            // In a real app, implement image picking functionality
            // For demo, just show a message
            Toast.makeText(this, "Image picker would open here in a real app", Toast.LENGTH_SHORT).show()
        }
    }
    
    private fun loadNoticeDetails() {
        // In a real app, fetch notice details from database or API
        // For demo, using a mock notice
        binding.progressBar.visibility = View.VISIBLE
        
        // Simulate network delay
        binding.root.postDelayed({
            // Create a mock notice based on ID
            val mockNotice = when (noticeId) {
                "1" -> Notice(
                    id = "1",
                    noticeDate = "Nov 10, 2023",
                    dueDate = "Nov 17, 2023",
                    description = "Submit your term papers by next week. Make sure to follow the guidelines provided in class.",
                    linkUrl = "https://example.com/term-papers",
                    coverImage = "https://picsum.photos/id/24/800/400"
                )
                "2" -> Notice(
                    id = "2",
                    noticeDate = "Oct 30, 2023",
                    dueDate = "Nov 4, 2023",
                    description = "School will be closed next Monday for the national holiday. All classes are canceled.",
                    linkUrl = "",
                    coverImage = "https://picsum.photos/id/164/800/400"
                )
                else -> Notice(
                    id = "3",
                    noticeDate = "Oct 25, 2023",
                    dueDate = "Nov 8, 2023",
                    description = "Annual science fair will be held on December 15th. Please register your projects by December 1st.",
                    linkUrl = "https://example.com/science-fair",
                    coverImage = "https://picsum.photos/id/250/800/400"
                )
            }
            
            // Populate fields with notice data
            binding.etNoticeDate.setText(mockNotice.noticeDate)
            binding.etDueDate.setText(mockNotice.dueDate)
            binding.etDescription.setText(mockNotice.description)
            binding.etLinkUrl.setText(mockNotice.linkUrl)
            
            // Load cover image
            Glide.with(this)
                .load(mockNotice.coverImage)
                .centerCrop()
                .into(binding.ivCoverImage)
            
            // Hide progress bar
            binding.progressBar.visibility = View.GONE
            
            // Parse dates
            try {
                val noticeDate = dateFormatter.parse(mockNotice.noticeDate)
                val dueDate = dateFormatter.parse(mockNotice.dueDate)
                
                if (noticeDate != null) {
                    selectedNoticeDate.time = noticeDate
                }
                if (dueDate != null) {
                    selectedDueDate.time = dueDate
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }, 800) // Simulated delay of 800ms
    }
    
    private fun validateInputs(): Boolean {
        var isValid = true
        
        // Validate description
        val description = binding.etDescription.text.toString().trim()
        if (description.isEmpty()) {
            binding.tilDescription.error = getString(R.string.error_empty_fields)
            isValid = false
        } else {
            binding.tilDescription.error = null
        }
        
        // Validate link URL (optional)
        val linkUrl = binding.etLinkUrl.text.toString().trim()
        if (linkUrl.isNotEmpty() && !android.util.Patterns.WEB_URL.matcher(linkUrl).matches()) {
            binding.tilLinkUrl.error = "Please enter a valid URL"
            isValid = false
        } else {
            binding.tilLinkUrl.error = null
        }
        
        return isValid
    }
    
    private fun saveNotice() {
        // In a real app, save to database or API
        // For demo, just show success and finish
        binding.progressBar.visibility = View.VISIBLE
        binding.btnSave.isEnabled = false
        
        // Simulate network delay
        binding.root.postDelayed({
            Toast.makeText(
                this,
                if (isEditMode) getString(R.string.success_update) else getString(R.string.success_save),
                Toast.LENGTH_SHORT
            ).show()
            finish()
        }, 1000)
    }
    
    // Handle toolbar back button
    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
} 