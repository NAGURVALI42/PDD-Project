package com.example.myapplication

import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.adapters.MessageAdapter
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.*

class AiChatbotActivity : AppCompatActivity() {

    private lateinit var toolbar: Toolbar
    private lateinit var recyclerView: RecyclerView
    private lateinit var etMessage: EditText
    private lateinit var btnSend: ImageButton
    private lateinit var progressBar: ProgressBar

    private val messageList = ArrayList<Message>()
    private lateinit var adapter: MessageAdapter
    private val client = OkHttpClient()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ai_chatbot)

        // UI Binding
        toolbar = findViewById(R.id.toolbar)
        recyclerView = findViewById(R.id.rvMessages)
        etMessage = findViewById(R.id.etMessage)
        btnSend = findViewById(R.id.btnSend)
        progressBar = findViewById(R.id.progressBar)

        // Toolbar Setup
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        // RecyclerView Setup
        adapter = MessageAdapter(this, messageList)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        // Welcome Message
        addMessage("Hello! I'm your AI assistant. How can I help you today?", isUser = false)

        // Send Button Click
        btnSend.setOnClickListener {
            val input = etMessage.text.toString().trim()
            if (input.isNotEmpty()) {
                etMessage.setText("")
                addMessage(input, isUser = true)
                sendToLocalPHPBot(input)
            }
        }
    }

    private fun addMessage(message: String, isUser: Boolean) {
        messageList.add(Message(message, isUser, Date()))
        adapter.notifyItemInserted(messageList.size - 1)
        recyclerView.scrollToPosition(messageList.size - 1)
    }

    private fun sendToLocalPHPBot(userMessage: String) {
        progressBar.visibility = View.VISIBLE

        val jsonBody = JSONObject().apply {
            put("messages", JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "user")
                    put("content", userMessage)
                })
            })
        }

        val mediaType = "application/json".toMediaType()
        val requestBody = jsonBody.toString().toRequestBody(mediaType)

        val request = Request.Builder()
            .url("http://192.168.220.17/school/api/chat.php")  // ✅ Ollama-based backend path
            .post(requestBody)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    progressBar.visibility = View.GONE
                    addMessage("❌ Failed to connect: ${e.localizedMessage}", isUser = false)
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val body = response.body?.string()
                runOnUiThread {
                    progressBar.visibility = View.GONE
                    try {
                        val reply = JSONObject(body!!)
                            .getJSONArray("choices")
                            .getJSONObject(0)
                            .getJSONObject("message")
                            .getString("content")
                        addMessage(reply.trim(), isUser = false)
                    } catch (e: Exception) {
                        addMessage("⚠️ Error parsing response", isUser = false)
                    }
                }
            }
        })
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            finish()
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    data class Message(val content: String, val isUser: Boolean, val timestamp: Date)
}
