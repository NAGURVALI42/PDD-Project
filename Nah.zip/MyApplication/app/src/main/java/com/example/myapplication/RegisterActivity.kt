package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.util.Patterns
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.databinding.ActivityRegisterBinding
import org.json.JSONObject

class RegisterActivity : AppCompatActivity() {
    private lateinit var binding: ActivityRegisterBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupListeners()
    }

    private fun setupListeners() {
        binding.rgRole.setOnCheckedChangeListener { _, checkedId ->
            binding.tilTeacherId.visibility = if (checkedId == R.id.rbTeacher) {
                View.VISIBLE
            } else {
                View.GONE
            }
        }

        binding.btnRegister.setOnClickListener {
            if (validateInputs()) {
                saveUserData()
            }
        }

        binding.tvLogin.setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }

    private fun validateInputs(): Boolean {
        var isValid = true

        if (binding.etName.text.toString().trim().isEmpty()) {
            binding.tilName.error = "Name is required"
            isValid = false
        } else {
            binding.tilName.error = null
        }

        val email = binding.etEmail.text.toString().trim()
        if (email.isEmpty()) {
            binding.tilEmail.error = "Email is required"
            isValid = false
        } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            binding.tilEmail.error = "Invalid email format"
            isValid = false
        } else {
            binding.tilEmail.error = null
        }

        if (binding.etUsername.text.toString().trim().isEmpty()) {
            binding.tilUsername.error = "Username is required"
            isValid = false
        } else {
            binding.tilUsername.error = null
        }

        val password = binding.etPassword.text.toString()
        val confirmPassword = binding.etConfirmPassword.text.toString()
        if (password.isEmpty()) {
            binding.tilPassword.error = "Password is required"
            isValid = false
        } else if (password.length < 6) {
            binding.tilPassword.error = "Password too short"
            isValid = false
        } else {
            binding.tilPassword.error = null
        }

        if (confirmPassword != password) {
            binding.tilConfirmPassword.error = "Passwords do not match"
            isValid = false
        } else {
            binding.tilConfirmPassword.error = null
        }

        if (binding.rbTeacher.isChecked) {
            if (binding.etTeacherId.text.toString().trim().isEmpty()) {
                binding.tilTeacherId.error = "Teacher ID required"
                isValid = false
            } else {
                binding.tilTeacherId.error = null
            }
        }

        return isValid
    }

    private fun saveUserData() {
        val username = binding.etUsername.text.toString().trim()
        val password = binding.etPassword.text.toString()
        val role = if (binding.rbTeacher.isChecked) "Teacher" else "Student"

        val sharedPref = getSharedPreferences("UserPrefs", MODE_PRIVATE)
        val existingUsersJson = sharedPref.getString("users_json", "{}")

        val users = JSONObject(existingUsersJson!!)
        if (users.has(username)) {
            Toast.makeText(this, "Username already exists!", Toast.LENGTH_SHORT).show()
            return
        }

        val userData = JSONObject().apply {
            put("password", password)
            put("role", role)
        }

        users.put(username, userData)

        with(sharedPref.edit()) {
            putString("users_json", users.toString())
            apply()
        }

        Toast.makeText(this, "Registered Successfully as $role", Toast.LENGTH_SHORT).show()

        val dashboardIntent = if (role == "Teacher") {
            Intent(this, TeacherDashboardActivity::class.java)
        } else {
            Intent(this, StudentDashboardActivity::class.java)
        }

        dashboardIntent.putExtra("USERNAME", username)
        dashboardIntent.putExtra("USER_ROLE", role)
        startActivity(dashboardIntent)
        finish()
    }
}
