package com.example.myapplication

import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.tabs.TabLayout

class SearchResultsActivity : AppCompatActivity() {

    private lateinit var toolbar: Toolbar
    private lateinit var tabLayout: TabLayout
    private lateinit var recyclerView: RecyclerView
    private lateinit var tvNoResults: TextView
    private lateinit var searchQuery: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search_results)

        // Get search query from intent
        searchQuery = intent.getStringExtra("SEARCH_QUERY") ?: ""

        initViews()
        setupToolbar()
        setupTabs()
        performSearch()
    }

    private fun initViews() {
        toolbar = findViewById(R.id.toolbar)
        tabLayout = findViewById(R.id.tabLayout)
        recyclerView = findViewById(R.id.recyclerView)
        tvNoResults = findViewById(R.id.tvNoResults)

        recyclerView.layoutManager = LinearLayoutManager(this)
    }

    private fun setupToolbar() {
        setSupportActionBar(toolbar)
        supportActionBar?.apply {
            title = "Search Results: \"$searchQuery\""
            setDisplayHomeAsUpEnabled(true)
            setDisplayShowHomeEnabled(true)
        }
    }

    private fun setupTabs() {
        // Add tabs for different search categories
        tabLayout.addTab(tabLayout.newTab().setText("All"))
        tabLayout.addTab(tabLayout.newTab().setText("Notices"))
        tabLayout.addTab(tabLayout.newTab().setText("Events"))
        tabLayout.addTab(tabLayout.newTab().setText("Work"))
        tabLayout.addTab(tabLayout.newTab().setText("Schedule"))

        tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                performSearch(tab.position)
            }

            override fun onTabUnselected(tab: TabLayout.Tab) {}

            override fun onTabReselected(tab: TabLayout.Tab) {}
        })
    }

    private fun performSearch(tabPosition: Int = 0) {
        // This is a mock implementation. In a real app, you would:
        // 1. Query your database based on the search term and category
        // 2. Pass the results to your recyclerView adapter

        recyclerView.visibility = View.GONE
        tvNoResults.visibility = View.VISIBLE
        tvNoResults.text = "No results found for \"$searchQuery\" in ${getTabName(tabPosition)}"

        // Example (real-world usage):
        // val results = repository.search(searchQuery, getTabName(tabPosition))
        // if (results.isEmpty()) {
        //     recyclerView.visibility = View.GONE
        //     tvNoResults.visibility = View.VISIBLE
        // } else {
        //     recyclerView.visibility = View.VISIBLE
        //     tvNoResults.visibility = View.GONE
        //     recyclerView.adapter = SearchResultsAdapter(results) { result ->
        //         navigateToDetail(result)
        //     }
        // }
    }

    private fun getTabName(position: Int): String {
        return when (position) {
            0 -> "All"
            1 -> "Notices"
            2 -> "Events"
            3 -> "Work"
            4 -> "Schedule"
            else -> "All"
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            onBackPressedDispatcher.onBackPressed() // ✅ modern replacement
            return true
        }
        return super.onOptionsItemSelected(item)
    }
}
