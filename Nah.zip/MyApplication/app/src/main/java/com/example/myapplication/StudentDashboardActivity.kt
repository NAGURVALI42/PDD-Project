package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.text.Editable
import android.text.TextWatcher
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import java.util.Locale

class StudentDashboardActivity : AppCompatActivity() {

    private lateinit var etSearch: EditText
    private lateinit var btnSearch: ImageView
    private lateinit var btnVoiceSearch: ImageButton
    private lateinit var cardNotices: CardView
    private lateinit var cardEvents: CardView
    private lateinit var cardWork: CardView
    private lateinit var cardSchedule: CardView
    private lateinit var cardSettings: CardView
    private lateinit var cardAiChat: CardView
    private lateinit var fabBack: FloatingActionButton

    private lateinit var currentUsername: String

    private val speechRecognizer = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            val data: Intent? = result.data
            val results = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            results?.get(0)?.let { text ->
                etSearch.setText(text)
                performSearch(text)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_student_dashboard)

        // ✅ Receive username from login or intent
        currentUsername = intent.getStringExtra("USERNAME") ?: ""

        if (currentUsername.isEmpty()) {
            Toast.makeText(this, "Username not found", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        initViews()
        setupListeners()
        setupSearchFunctionality()
    }

    private fun initViews() {
        etSearch = findViewById(R.id.etSearch)
        btnSearch = findViewById(R.id.btnSearch)
        btnVoiceSearch = findViewById(R.id.btnVoiceSearch)
        cardNotices = findViewById(R.id.cardNotices)
        cardEvents = findViewById(R.id.cardEvents)
        cardWork = findViewById(R.id.cardWork)
        cardSchedule = findViewById(R.id.cardSchedule)
        cardSettings = findViewById(R.id.cardSettings)
        cardAiChat = findViewById(R.id.cardAiChat)
        fabBack = findViewById(R.id.fabBack)
    }

    private fun setupListeners() {
        fabBack.setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }

        btnVoiceSearch.setOnClickListener {
            startVoiceRecognition()
        }

        btnSearch.setOnClickListener {
            performSearch(etSearch.text.toString())
        }

        cardNotices.setOnClickListener {
            startActivity(Intent(this, StudentNoticesActivity::class.java))
        }

        cardEvents.setOnClickListener {
            startActivity(Intent(this, StudentEventsActivity::class.java))
        }

        cardWork.setOnClickListener {
            startActivity(Intent(this, StudentWorkActivity::class.java))
        }

        cardSchedule.setOnClickListener {
            startActivity(Intent(this, StudentScheduleActivity::class.java))
        }

        cardSettings.setOnClickListener {
            val intent = Intent(this, TeacherSettingsActivity::class.java)
            intent.putExtra("IS_TEACHER", false)
            intent.putExtra("USERNAME", currentUsername) // ✅ Pass username
            startActivity(intent)
        }

        cardAiChat.setOnClickListener {
            val intent = Intent(this, AiChatbotActivity::class.java)
            intent.putExtra("SEARCH_QUERY", "")
            startActivity(intent)
        }
    }

    private fun setupSearchFunctionality() {
        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                s?.toString()?.let { query ->
                    if (query.isNotEmpty() && query.length >= 3) {
                        performSearch(query)
                    }
                }
            }
        })
    }

    private fun startVoiceRecognition() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, getString(R.string.speak_now))

        try {
            speechRecognizer.launch(intent)
        } catch (e: Exception) {
            Toast.makeText(this, getString(R.string.speech_not_supported), Toast.LENGTH_SHORT).show()
        }
    }

    private fun performSearch(query: String) {
        if (query.isEmpty()) return

        when {
            query.contains("notice", ignoreCase = true) -> {
                startActivity(Intent(this, StudentNoticesActivity::class.java).putExtra("SEARCH_QUERY", query))
            }

            query.contains("event", ignoreCase = true) -> {
                startActivity(Intent(this, StudentEventsActivity::class.java).putExtra("SEARCH_QUERY", query))
            }

            query.contains("work", ignoreCase = true) || query.contains("assignment", ignoreCase = true) -> {
                startActivity(Intent(this, StudentWorkActivity::class.java).putExtra("SEARCH_QUERY", query))
            }

            query.contains("schedule", ignoreCase = true) || query.contains("timetable", ignoreCase = true) -> {
                startActivity(Intent(this, StudentScheduleActivity::class.java).putExtra("SEARCH_QUERY", query))
            }

            query.contains("settings", ignoreCase = true) -> {
                val intent = Intent(this, TeacherSettingsActivity::class.java)
                intent.putExtra("IS_TEACHER", false)
                intent.putExtra("USERNAME", currentUsername) // ✅ Fix for settings
                startActivity(intent)
            }

            query.contains("chat", ignoreCase = true) || query.contains("ai", ignoreCase = true) -> {
                startActivity(Intent(this, AiChatbotActivity::class.java).putExtra("SEARCH_QUERY", query))
            }

            else -> {
                Toast.makeText(this, "Searching for: $query", Toast.LENGTH_SHORT).show()
                val intent = Intent(this, SearchResultsActivity::class.java)
                intent.putExtra("SEARCH_QUERY", query)
                startActivity(intent)
            }
        }
    }
}
