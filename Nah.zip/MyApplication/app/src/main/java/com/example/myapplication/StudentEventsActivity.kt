package com.example.myapplication

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.example.myapplication.databinding.ActivityStudentEventsBinding
import com.example.myapplication.fragments.StudentCalendarEventsFragment
import com.example.myapplication.fragments.StudentPastEventsFragment
import com.example.myapplication.fragments.StudentUpcomingEventsFragment
import com.google.android.material.tabs.TabLayoutMediator
import java.text.SimpleDateFormat
import java.util.*

class StudentEventsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityStudentEventsBinding
    private val selectedDateFormat = SimpleDateFormat("dd", Locale.getDefault())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStudentEventsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupViewPager()
        setupTabLayout()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }
    }

    private fun setupViewPager() {
        binding.viewPager.adapter = EventsPagerAdapter(this)
        binding.viewPager.isUserInputEnabled = false
    }

    private fun setupTabLayout() {
        TabLayoutMediator(binding.tabLayout, binding.viewPager) { tab, position ->
            tab.text = when (position) {
                0 -> getString(R.string.upcoming)
                1 -> getString(R.string.calendar)
                2 -> getString(R.string.past)
                else -> null
            }
        }.attach()
    }

    inner class EventsPagerAdapter(activity: AppCompatActivity) :
        FragmentStateAdapter(activity) {
        override fun getItemCount() = 3

        override fun createFragment(position: Int): Fragment {
            return when (position) {
                0 -> StudentUpcomingEventsFragment.newInstance()
                1 -> StudentCalendarEventsFragment.newInstance()
                2 -> StudentPastEventsFragment.newInstance()
                else -> throw IllegalArgumentException("Invalid tab position: $position")
            }
        }
    }

    override fun onResume() {
        super.onResume()

        // Refresh current fragment via a consistent interface
        val currentItem = binding.viewPager.currentItem
        val tag = "f$currentItem"  // ViewPager2 fragment tag convention
        val fragment = supportFragmentManager.findFragmentByTag(tag)
        if (fragment is Refreshable) {
            fragment.refreshEvents()
        }
    }

    interface Refreshable {
        fun refreshEvents()
    }
}
