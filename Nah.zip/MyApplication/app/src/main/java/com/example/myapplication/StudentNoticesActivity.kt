package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myapplication.adapters.StudentNoticeAdapter
import com.example.myapplication.data.Notice
import com.example.myapplication.databinding.ActivityStudentNoticesBinding
import com.google.android.material.tabs.TabLayout
import java.util.*

class StudentNoticesActivity : AppCompatActivity() {

    private lateinit var binding: ActivityStudentNoticesBinding
    private lateinit var noticeAdapter: StudentNoticeAdapter
    private val filteredNoticesList = mutableListOf<Notice>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStudentNoticesBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupRecyclerView()
        setupSearch()
        setupTabLayout()
        setupSwipeToRefresh()
        loadTeacherNotices()
    }

    override fun onResume() {
        super.onResume()
        loadTeacherNotices()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }
    }

    private fun setupRecyclerView() {
        noticeAdapter = StudentNoticeAdapter(
            notices = filteredNoticesList,
            onItemClick = { notice -> openNoticeDetail(notice) },
            onShareClick = { notice -> shareNotice(notice) }
        )
        binding.recyclerView.apply {
            layoutManager = LinearLayoutManager(this@StudentNoticesActivity)
            adapter = noticeAdapter
        }
    }

    private fun setupSearch() {
        binding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                filterNotices(s.toString())
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
    }

    private fun setupTabLayout() {
        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                when (tab.position) {
                    0 -> filterNoticesByAge("new")
                    1 -> filterNoticesByAge("earlier")
                    2 -> filterNoticesByAge("all")
                }
            }

            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })
    }

    private fun setupSwipeToRefresh() {
        binding.swipeRefresh.setOnRefreshListener {
            loadTeacherNotices()
        }
    }

    private fun loadTeacherNotices() {
        binding.progressBar.visibility = View.VISIBLE

        // Clear and reload from shared TeacherNoticesActivity list
        filteredNoticesList.clear()
        filteredNoticesList.addAll(TeacherNoticesActivity.noticeList) // << REAL DATA

        noticeAdapter.notifyDataSetChanged()
        updateEmptyView()
        binding.progressBar.visibility = View.GONE
        binding.swipeRefresh.isRefreshing = false
    }

    private fun filterNotices(query: String?) {
        val allNotices = TeacherNoticesActivity.noticeList
        filteredNoticesList.clear()

        if (query.isNullOrBlank()) {
            filteredNoticesList.addAll(allNotices)
        } else {
            val lowerQuery = query.lowercase()
            filteredNoticesList.addAll(allNotices.filter {
                it.title.lowercase().contains(lowerQuery) ||
                        it.description.lowercase().contains(lowerQuery)
            })
        }

        noticeAdapter.notifyDataSetChanged()
        updateEmptyView()
    }

    private fun filterNoticesByAge(age: String) {
        val allNotices = TeacherNoticesActivity.noticeList
        val oneWeekAgo = Calendar.getInstance().apply {
            add(Calendar.DAY_OF_MONTH, -7)
        }.time

        filteredNoticesList.clear()
        when (age) {
            "new" -> filteredNoticesList.addAll(allNotices.filter { it.noticeDate >= oneWeekAgo })
            "earlier" -> filteredNoticesList.addAll(allNotices.filter { it.noticeDate < oneWeekAgo })
            "all" -> filteredNoticesList.addAll(allNotices)
        }

        noticeAdapter.notifyDataSetChanged()
        updateEmptyView()
    }

    private fun updateEmptyView() {
        binding.tvEmpty.visibility = if (filteredNoticesList.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun openNoticeDetail(notice: Notice) {
        Toast.makeText(this, "Viewing: ${notice.title}", Toast.LENGTH_SHORT).show()
        // Optionally: launch a new detail screen for full image, link etc.
    }

    private fun shareNotice(notice: Notice) {
        val shareText = """
            ${notice.title}
            ${notice.description}
            Due: ${notice.dueDateFormatted}
        """.trimIndent()

        startActivity(Intent.createChooser(
            Intent(Intent.ACTION_SEND)
                .putExtra(Intent.EXTRA_TEXT, shareText)
                .setType("text/plain"),
            "Share notice via"
        ))
    }
}
