package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myapplication.adapters.StudentWorkAdapter
import com.example.myapplication.data.Work
import com.example.myapplication.databinding.ActivityStudentWorkBinding
import com.google.android.material.tabs.TabLayout
import java.util.*

class StudentWorkActivity : AppCompatActivity() {

    private lateinit var binding: ActivityStudentWorkBinding
    private lateinit var workAdapter: StudentWorkAdapter
    private val workList = mutableListOf<Work>()
    private val filteredWorkList = mutableListOf<Work>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStudentWorkBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupRecyclerView()
        setupSearch()
        setupTabLayout()
        loadWorkFromTeacher()
    }

    override fun onResume() {
        super.onResume()
        refreshWork()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }
    }

    private fun setupRecyclerView() {
        workAdapter = StudentWorkAdapter(
            filteredWorkList,
            onItemClick = { openWorkDetail(it) },
            onShareClick = { shareWork(it) },
            onDocumentClick = { openDocument(it) }
        )
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = workAdapter
        binding.swipeRefresh.setOnRefreshListener { refreshWork() }
    }

    private fun setupSearch() {
        binding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                filterWork(s.toString())
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        binding.ivFilter.setOnClickListener { showFilterOptions() }
    }

    private fun setupTabLayout() {
        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                filterWorkByStatus(
                    when (tab.position) {
                        1 -> "active"
                        2 -> "completed"
                        else -> "all"
                    }
                )
            }

            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })
    }

    private fun loadWorkFromTeacher() {
        binding.swipeRefresh.isRefreshing = true

        // Load from TeacherWorkActivity's shared list
        workList.clear()
        workList.addAll(TeacherWorkActivity.workList)

        filteredWorkList.clear()
        filteredWorkList.addAll(workList)

        updateEmptyView()
        workAdapter.notifyDataSetChanged()
        binding.swipeRefresh.isRefreshing = false
    }

    private fun refreshWork() = loadWorkFromTeacher()

    private fun filterWork(query: String?) {
        filteredWorkList.apply {
            clear()
            if (query.isNullOrBlank()) addAll(workList)
            else addAll(workList.filter { work ->
                work.title.contains(query, ignoreCase = true) ||
                        work.description.contains(query, ignoreCase = true) ||
                        work.subjectList.any { subject -> subject.contains(query, ignoreCase = true) }
            })
        }
        updateEmptyView()
        workAdapter.notifyDataSetChanged()
    }

    private fun filterWorkByStatus(status: String) {
        val now = Date()
        filteredWorkList.apply {
            clear()
            addAll(
                when (status) {
                    "active" -> workList.filter { it.dueDate?.after(now) ?: false }
                    "completed" -> workList.filter { it.dueDate?.let { !it.after(now) } ?: false }
                    else -> workList
                }
            )
        }
        updateEmptyView()
        workAdapter.notifyDataSetChanged()
    }

    private fun showFilterOptions() {
        val subjects = arrayOf("All", "Mathematics", "Science", "English", "History", "Geography")
        android.app.AlertDialog.Builder(this)
            .setTitle("Filter by Subject")
            .setItems(subjects) { _, i ->
                filterWork(if (i == 0) null else subjects[i])
            }
            .show()
    }

    private fun updateEmptyView() {
        binding.tvEmpty.visibility =
            if (filteredWorkList.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun openWorkDetail(work: Work) {
        Toast.makeText(this, "Viewing: ${work.title}", Toast.LENGTH_SHORT).show()
    }

    private fun shareWork(work: Work) {
        startActivity(Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, work.title)
            putExtra(Intent.EXTRA_TEXT, work.description)
        })
    }

    private fun openDocument(url: String) {
        Toast.makeText(this, "Opening: $url", Toast.LENGTH_SHORT).show()
    }
}
