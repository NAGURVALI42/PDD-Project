package com.example.myapplication

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.data.Event
import com.example.myapplication.data.EventRepository
import com.example.myapplication.databinding.TeacherAddEventBinding
import java.text.SimpleDateFormat
import java.util.*

class TeacherAddEventActivity : AppCompatActivity() {

    private lateinit var binding: TeacherAddEventBinding
    private var selectedImageUri: Uri? = null
    private val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
    private val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())

    private var selectedStartDate = Calendar.getInstance()
    private var selectedEndDate = Calendar.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = TeacherAddEventBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupListeners()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        binding.toolbar.setNavigationOnClickListener { onBackPressedDispatcher.onBackPressed() }
    }

    private fun setupListeners() {
        val imagePickerLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            uri?.let {
                selectedImageUri = it
                binding.ivEventCover.setImageURI(it)
                binding.ivEventCover.visibility = android.view.View.VISIBLE
                binding.layoutAddImage.visibility = android.view.View.GONE
            }
        }

        binding.layoutAddImage.setOnClickListener {
            imagePickerLauncher.launch("image/*")
        }

        binding.etEventDate.setOnClickListener {
            showDatePicker(selectedStartDate) {
                binding.etEventDate.setText(dateFormat.format(it.time))
            }
        }

        binding.etStartTime.setOnClickListener {
            showTimePicker(selectedStartDate) {
                binding.etStartTime.setText(timeFormat.format(it.time))
            }
        }

        binding.etEndTime.setOnClickListener {
            showTimePicker(selectedEndDate) {
                binding.etEndTime.setText(timeFormat.format(it.time))
            }
        }

        binding.btnSaveEvent.setOnClickListener {
            saveEvent()
        }
    }

    private fun showDatePicker(calendar: Calendar, onDateSelected: (Calendar) -> Unit) {
        DatePickerDialog(this, { _, year, month, day ->
            calendar.set(year, month, day)
            onDateSelected(calendar)
        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun showTimePicker(calendar: Calendar, onTimeSelected: (Calendar) -> Unit) {
        TimePickerDialog(this, { _, hour, minute ->
            calendar.set(Calendar.HOUR_OF_DAY, hour)
            calendar.set(Calendar.MINUTE, minute)
            onTimeSelected(calendar)
        }, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), true).show()
    }

    private fun saveEvent() {
        val name = binding.etEventName.text.toString().trim()
        val description = binding.etDescription.text.toString().trim()

        if (name.isEmpty() || description.isEmpty() || binding.etEventDate.text.isNullOrEmpty()
            || binding.etStartTime.text.isNullOrEmpty() || binding.etEndTime.text.isNullOrEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
            return
        }

        val event = Event(
            id = UUID.randomUUID().toString(), // ensure unique ID
            title = name,
            description = description,
            startDate = selectedStartDate.time,
            endDate = selectedEndDate.time,
            imageUrl = selectedImageUri?.toString() ?: ""
        )

        EventRepository.addEvent(event)
        Toast.makeText(this, "Event Saved!", Toast.LENGTH_SHORT).show()
        finish()
    }
}
