package com.example.myapplication

import android.app.Activity
import android.app.DatePickerDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.data.Notice
import com.example.myapplication.databinding.ActivityTeacherAddNoticeBinding
import java.text.SimpleDateFormat
import java.util.*

class TeacherAddNoticeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityTeacherAddNoticeBinding
    private var selectedImageUri: Uri? = null
    private var selectedDueDate: Date? = null

    private val pickImage = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let { uri ->
                selectedImageUri = uri
                binding.ivNoticeCover.visibility = View.VISIBLE
                binding.ivNoticeCover.setImageURI(uri)
                binding.layoutAddImage.visibility = View.GONE
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTeacherAddNoticeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupImagePicker()
        setupDatePicker()
        setupSaveButton()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { onBackPressed() }
    }

    private fun setupImagePicker() {
        binding.cardImage.setOnClickListener {
            val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            pickImage.launch(intent)
        }
    }

    private fun setupDatePicker() {
        binding.etDueDate.setOnClickListener {
            val cal = Calendar.getInstance()
            DatePickerDialog(
                this,
                { _, y, m, d ->
                    cal.set(y, m, d)
                    selectedDueDate = cal.time
                    val fmt = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
                    binding.etDueDate.setText(fmt.format(cal.time))
                },
                cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)
            ).apply { datePicker.minDate = cal.timeInMillis }
                .show()
        }
    }

    private fun setupSaveButton() {
        binding.btnSaveNotice.setOnClickListener {
            if (validateForm()) {
                saveNotice(isPublish = false)
            }
        }
    }

    private fun validateForm(): Boolean {
        var ok = true
        if (binding.etTitle.text.toString().trim().isEmpty()) {
            binding.tilTitle.error = "Title is required"
            ok = false
        } else binding.tilTitle.error = null

        if (binding.etDescription.text.toString().trim().isEmpty()) {
            binding.tilDescription.error = "Description is required"
            ok = false
        } else binding.tilDescription.error = null

        return ok
    }

    private fun saveNotice(isPublish: Boolean) {
        val notice = Notice(
            id = UUID.randomUUID().toString(),
            title = binding.etTitle.text.toString(),
            description = binding.etDescription.text.toString(),
            noticeDate = Date(),
            dueDate = selectedDueDate,
            coverImageUrl = selectedImageUri?.toString(),
            linkUrl = binding.etLinkUrl.text.toString().takeIf { it.isNotBlank() },
            status = if (isPublish) "active" else "draft"
        )

        // Add to shared list
        TeacherNoticesActivity.noticeList.add(notice)

        Toast.makeText(
            this,
            if (isPublish) "Notice published" else "Saved as draft",
            Toast.LENGTH_SHORT
        ).show()
        setResult(Activity.RESULT_OK)
        finish()
    }
}
