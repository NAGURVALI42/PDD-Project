package com.example.myapplication

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.databinding.ActivityTeacherAddScheduleBinding
import com.example.myapplication.models.Schedule
import com.example.myapplication.data.ScheduleRepository
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*

class TeacherAddScheduleActivity : AppCompatActivity() {

    private lateinit var binding: ActivityTeacherAddScheduleBinding

    private val calendar = Calendar.getInstance()
    private var selectedDate: Date? = null

    private val timeFormat = SimpleDateFormat("hh:mm a", Locale.getDefault())
    private val dateFormat = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault())

    private val daysOfWeek = listOf("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday")
    private val scheduleTypes = listOf("Regular", "Exam", "Holiday", "Meeting", "Activity")
    private val classList = listOf("Class 10A", "Class 10B", "Class 9A", "Class 9B")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTeacherAddScheduleBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }

        // Setup spinners
        binding.spinnerClass.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, classList)
        binding.spinnerDay.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, daysOfWeek)
        binding.spinnerType.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, scheduleTypes)

        setupDateAndTimePickers()

        binding.btnSave.setOnClickListener {
            if (validateInput()) {
                try {
                    val startTime = timeFormat.parse(binding.etStartTime.text.toString())
                    val endTime = timeFormat.parse(binding.etEndTime.text.toString())

                    if (startTime != null && endTime != null && selectedDate != null) {
                        val selectedClassName = binding.spinnerClass.selectedItem.toString()
                        val classId = getClassIdFromName(selectedClassName)

                        val schedule = Schedule(
                            scheduleType = binding.spinnerType.selectedItem.toString(),
                            className = selectedClassName,
                            classId = classId,   // Added classId here
                            subjectName = binding.etSubject.text.toString().trim(),
                            scheduleDate = selectedDate!!,
                            startTime = startTime,
                            endTime = endTime,
                            notes = binding.etNotes.text?.toString()?.trim() ?: "",
                            createdBy = "Teacher"
                        )

                        ScheduleRepository.addSchedule(schedule)
                        Toast.makeText(this, "Schedule added successfully", Toast.LENGTH_SHORT).show()
                        finish()
                    }
                } catch (e: ParseException) {
                    e.printStackTrace()
                    Toast.makeText(this, "Invalid time format", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun setupDateAndTimePickers() {
        binding.etDate.setOnClickListener {
            val now = Calendar.getInstance()
            DatePickerDialog(this, { _, year, month, dayOfMonth ->
                calendar.set(year, month, dayOfMonth)
                selectedDate = calendar.time
                binding.etDate.setText(dateFormat.format(selectedDate!!))
            }, now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH)).show()
        }

        val timePicker = { isStart: Boolean ->
            val now = Calendar.getInstance()
            TimePickerDialog(this, { _, hour, minute ->
                val cal = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, hour)
                    set(Calendar.MINUTE, minute)
                }
                val timeStr = timeFormat.format(cal.time)
                if (isStart) binding.etStartTime.setText(timeStr)
                else binding.etEndTime.setText(timeStr)
            }, now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), false).show()
        }

        binding.etStartTime.setOnClickListener { timePicker(true) }
        binding.etEndTime.setOnClickListener { timePicker(false) }
    }

    private fun validateInput(): Boolean {
        var isValid = true

        if (binding.etSubject.text.isNullOrBlank()) {
            binding.etSubject.error = "Required"
            isValid = false
        }

        if (binding.etStartTime.text.isNullOrBlank()) {
            binding.etStartTime.error = "Required"
            isValid = false
        }

        if (binding.etEndTime.text.isNullOrBlank()) {
            binding.etEndTime.error = "Required"
            isValid = false
        }

        if (selectedDate == null) {
            binding.etDate.error = "Pick a date"
            isValid = false
        }

        return isValid
    }

    // Helper to convert class name to classId (you can adjust IDs as per your DB or logic)
    private fun getClassIdFromName(className: String): Int {
        return when (className) {
            "Class 10A" -> 1
            "Class 10B" -> 2
            "Class 9A" -> 3
            "Class 9B" -> 4
            else -> 0
        }
    }
}
