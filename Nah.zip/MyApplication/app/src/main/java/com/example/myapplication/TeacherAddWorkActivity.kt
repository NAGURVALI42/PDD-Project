package com.example.myapplication

import android.app.Activity
import android.app.DatePickerDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myapplication.adapters.DocumentUploadAdapter
import com.example.myapplication.data.Work
import com.example.myapplication.databinding.ActivityTeacherAddWorkBinding
import java.text.SimpleDateFormat
import java.util.*

class TeacherAddWorkActivity : AppCompatActivity() {

    private lateinit var binding: ActivityTeacherAddWorkBinding
    private val documentsList = mutableListOf<String>()
    private lateinit var documentAdapter: DocumentUploadAdapter
    private var assignedDate: Date = Calendar.getInstance().time
    private var dueDate: Date? = null
    private val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())

    // Document picker
    private val documentPicker = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let { uri ->
                addDocumentToList(uri)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTeacherAddWorkBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupDatePickers()
        setupDocumentsList()
        setupSaveButton()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener {
            finish()
        }
    }

    private fun setupDatePickers() {
        binding.etAssignedDate.setText(dateFormat.format(assignedDate))

        binding.tilAssignedDate.setEndIconOnClickListener { showDatePickerDialog(true) }
        binding.etAssignedDate.setOnClickListener { showDatePickerDialog(true) }

        binding.tilDueDate.setEndIconOnClickListener { showDatePickerDialog(false) }
        binding.etDueDate.setOnClickListener { showDatePickerDialog(false) }
    }

    private fun setupDocumentsList() {
        documentAdapter = DocumentUploadAdapter(
            documentsList,
            onDeleteClick = { position ->
                documentsList.removeAt(position)
                documentAdapter.notifyItemRemoved(position)
                updateDocumentsVisibility()
            }
        )

        binding.rvDocuments.apply {
            layoutManager = LinearLayoutManager(this@TeacherAddWorkActivity)
            adapter = documentAdapter
        }

        binding.btnAddDocument.setOnClickListener {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
                putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                    "application/pdf",
                    "application/msword",
                    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                    "image/*"
                ))
            }
            documentPicker.launch(intent)
        }

        updateDocumentsVisibility()
    }

    private fun setupSaveButton() {
        binding.btnSave.setOnClickListener {
            if (validateInputs()) {
                saveWorkAssignment()
            }
        }
    }

    private fun showDatePickerDialog(isAssignedDate: Boolean) {
        val calendar = Calendar.getInstance()
        if (isAssignedDate && assignedDate != null) {
            calendar.time = assignedDate
        } else if (!isAssignedDate && dueDate != null) {
            calendar.time = dueDate!!
        }

        DatePickerDialog(
            this,
            { _, year, month, dayOfMonth ->
                calendar.set(Calendar.YEAR, year)
                calendar.set(Calendar.MONTH, month)
                calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth)

                val selectedDate = calendar.time
                val formattedDate = dateFormat.format(selectedDate)

                if (isAssignedDate) {
                    assignedDate = selectedDate
                    binding.etAssignedDate.setText(formattedDate)
                } else {
                    dueDate = selectedDate
                    binding.etDueDate.setText(formattedDate)
                }
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    private fun addDocumentToList(uri: Uri) {
        documentsList.add(uri.toString())
        documentAdapter.notifyItemInserted(documentsList.size - 1)
        updateDocumentsVisibility()
    }

    private fun updateDocumentsVisibility() {
        binding.rvDocuments.visibility = if (documentsList.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun validateInputs(): Boolean {
        var isValid = true

        if (binding.etTitle.text.isNullOrBlank()) {
            binding.tilTitle.error = "Title is required"
            isValid = false
        } else {
            binding.tilTitle.error = null
        }

        if (binding.etDescription.text.isNullOrBlank()) {
            binding.tilDescription.error = "Description is required"
            isValid = false
        } else {
            binding.tilDescription.error = null
        }

        if (dueDate != null && dueDate!!.before(assignedDate)) {
            binding.tilDueDate.error = "Due date must be after assigned date"
            isValid = false
        } else {
            binding.tilDueDate.error = null
        }

        return isValid
    }

    private fun saveWorkAssignment() {
        val selectedSubjects = mutableListOf<String>()
        if (binding.chipMath.isChecked) selectedSubjects.add("Mathematics")
        if (binding.chipScience.isChecked) selectedSubjects.add("Science")
        if (binding.chipEnglish.isChecked) selectedSubjects.add("English")
        if (binding.chipHistory.isChecked) selectedSubjects.add("History")
        if (binding.chipGeography.isChecked) selectedSubjects.add("Geography")

        val work = Work(
            title = binding.etTitle.text.toString(),
            description = binding.etDescription.text.toString(),
            assignedDate = assignedDate,
            dueDate = dueDate,
            subjectList = selectedSubjects,
            documentUrls = documentsList
        )

        // ✅ Add to shared work list so it's reflected on main screen
        TeacherWorkActivity.workList.add(0, work)

        Toast.makeText(this, "Work assignment created successfully", Toast.LENGTH_SHORT).show()
        finish()
    }
}
