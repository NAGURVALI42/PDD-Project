package com.example.myapplication

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.data.Event
import com.example.myapplication.data.EventRepository
import com.example.myapplication.databinding.ActivityTeacherEditEventBinding
import java.text.SimpleDateFormat
import java.util.*

class TeacherEditEventActivity : AppCompatActivity() {

    private lateinit var binding: ActivityTeacherEditEventBinding
    private var eventId: String? = null
    private lateinit var currentEvent: Event

    private val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
    private val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
    private var startCalendar = Calendar.getInstance()
    private var endCalendar = Calendar.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTeacherEditEventBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupEventTypeSpinner()

        eventId = intent.getStringExtra("EVENT_ID")
        if (eventId == null) {
            Toast.makeText(this, "Event not found", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        currentEvent = EventRepository.getEventById(eventId!!) ?: run {
            Toast.makeText(this, "Event not found", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        populateEventDetails()
        setupListeners()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        binding.toolbar.setNavigationOnClickListener { finish() }
    }

    private fun setupEventTypeSpinner() {
        val types = arrayOf("School", "Cultural", "Sports", "Holiday", "Exam", "Other")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, types)
        binding.spinnerEventType.adapter = adapter
    }

    private fun populateEventDetails() {
        binding.etTitle.setText(currentEvent.title)
        binding.etDescription.setText(currentEvent.description)
        binding.etLocation.setText(currentEvent.location)

        startCalendar.time = currentEvent.startDate
        endCalendar.time = currentEvent.endDate ?: currentEvent.startDate

        binding.etStartDate.setText(dateFormat.format(startCalendar.time))
        binding.etEndDate.setText(dateFormat.format(endCalendar.time))
        binding.etStartTime.setText(timeFormat.format(startCalendar.time))
        binding.etEndTime.setText(timeFormat.format(endCalendar.time))

        val position = (binding.spinnerEventType.adapter as ArrayAdapter<String>)
            .getPosition(currentEvent.eventType)
        binding.spinnerEventType.setSelection(position)
    }

    private fun setupListeners() {
        binding.etStartDate.setOnClickListener {
            showDatePicker(startCalendar) { binding.etStartDate.setText(dateFormat.format(it.time)) }
        }

        binding.etEndDate.setOnClickListener {
            showDatePicker(endCalendar) { binding.etEndDate.setText(dateFormat.format(it.time)) }
        }

        binding.etStartTime.setOnClickListener {
            showTimePicker(startCalendar) { binding.etStartTime.setText(timeFormat.format(it.time)) }
        }

        binding.etEndTime.setOnClickListener {
            showTimePicker(endCalendar) { binding.etEndTime.setText(timeFormat.format(it.time)) }
        }

        binding.btnSave.setOnClickListener {
            updateEvent()
        }

        binding.btnDelete.setOnClickListener {
            deleteEvent()
        }
    }

    private fun showDatePicker(calendar: Calendar, onSelected: (Calendar) -> Unit) {
        DatePickerDialog(
            this,
            { _, year, month, day ->
                calendar.set(year, month, day)
                onSelected(calendar)
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    private fun showTimePicker(calendar: Calendar, onSelected: (Calendar) -> Unit) {
        TimePickerDialog(
            this,
            { _, hour, minute ->
                calendar.set(Calendar.HOUR_OF_DAY, hour)
                calendar.set(Calendar.MINUTE, minute)
                onSelected(calendar)
            },
            calendar.get(Calendar.HOUR_OF_DAY),
            calendar.get(Calendar.MINUTE),
            true
        ).show()
    }

    private fun updateEvent() {
        currentEvent = currentEvent.copy(
            title = binding.etTitle.text.toString().trim(),
            description = binding.etDescription.text.toString().trim(),
            location = binding.etLocation.text.toString().trim(),
            startDate = startCalendar.time,
            endDate = endCalendar.time,
            eventType = binding.spinnerEventType.selectedItem.toString()
        )

        EventRepository.updateEvent(currentEvent)
        Toast.makeText(this, "Event updated", Toast.LENGTH_SHORT).show()
        finish()
    }

    private fun deleteEvent() {
        EventRepository.deleteEvent(currentEvent.id)
        Toast.makeText(this, "Event deleted", Toast.LENGTH_SHORT).show()
        finish()
    }
}
