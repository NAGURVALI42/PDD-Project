package com.example.myapplication

import android.app.Activity
import android.app.DatePickerDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.example.myapplication.data.Notice
import com.example.myapplication.databinding.ActivityTeacherEditNoticeBinding
import java.text.SimpleDateFormat
import java.util.*

class TeacherEditNoticeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityTeacherEditNoticeBinding
    private var selectedImageUri: Uri? = null
    private var selectedDueDate: Date? = null
    private var currentNotice: Notice? = null
    private var noticeId: String? = null

    private val pickImage =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                result.data?.data?.let { uri ->
                    selectedImageUri = uri
                    binding.ivNoticeCover.setImageURI(uri)
                    binding.ivNoticeCover.visibility = View.VISIBLE
                }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTeacherEditNoticeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        noticeId = intent.getStringExtra("NOTICE_ID")
        if (noticeId == null) {
            Toast.makeText(this, "Error: Notice not found", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        setupToolbar()
        loadNoticeData()
        setupImagePicker()
        setupDatePicker()
        setupButtons()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }
    }

    private fun loadNoticeData() {
        // Load actual notice from shared list
        currentNotice = TeacherNoticesActivity.noticeList.find { it.id == noticeId }

        if (currentNotice == null) {
            Toast.makeText(this, "Notice not found", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        currentNotice?.let {
            binding.etTitle.setText(it.title)
            binding.etDescription.setText(it.description)
            binding.etLinkUrl.setText(it.linkUrl ?: "")

            it.dueDate?.let { date ->
                selectedDueDate = date
                binding.etDueDate.setText(SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(date))
            }

            it.coverImageUrl?.let { url ->
                binding.ivNoticeCover.visibility = View.VISIBLE
                Glide.with(this)
                    .load(url)
                    .into(binding.ivNoticeCover)
                selectedImageUri = Uri.parse(url)
            }
        }
    }

    private fun setupImagePicker() {
        binding.layoutChangeImage.setOnClickListener {
            val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            pickImage.launch(intent)
        }
    }

    private fun setupDatePicker() {
        binding.etDueDate.setOnClickListener { showDatePicker() }
    }

    private fun showDatePicker() {
        val cal = Calendar.getInstance()
        selectedDueDate?.let { cal.time = it }

        DatePickerDialog(
            this,
            { _, y, m, d ->
                cal.set(y, m, d)
                selectedDueDate = cal.time
                binding.etDueDate.setText(SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(cal.time))
            },
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH),
            cal.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    private fun setupButtons() {
        binding.btnDeleteNotice.setOnClickListener { confirmDelete() }
        binding.btnSaveNotice.setOnClickListener {
            if (validate()) performUpdate(false)
        }
    }

    private fun confirmDelete() {
        AlertDialog.Builder(this)
            .setTitle("Delete Notice")
            .setMessage("Are you sure?")
            .setPositiveButton("Yes") { _, _ ->
                TeacherNoticesActivity.noticeList.removeIf { it.id == noticeId }
                Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show()
                setResult(Activity.RESULT_OK)
                finish()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun validate(): Boolean {
        var ok = true
        binding.etTitle.apply {
            if (text.isNullOrBlank()) {
                error = "Required"
                ok = false
            }
        }
        binding.etDescription.apply {
            if (text.isNullOrBlank()) {
                error = "Required"
                ok = false
            }
        }
        return ok
    }

    private fun performUpdate(publish: Boolean) {
        currentNotice = currentNotice?.copy(
            title = binding.etTitle.text.toString(),
            description = binding.etDescription.text.toString(),
            dueDate = selectedDueDate,
            coverImageUrl = selectedImageUri?.toString(),
            linkUrl = binding.etLinkUrl.text.toString(),
            status = if (publish) "active" else currentNotice!!.status
        )

        currentNotice?.let { updated ->
            val index = TeacherNoticesActivity.noticeList.indexOfFirst { it.id == updated.id }
            if (index != -1) {
                TeacherNoticesActivity.noticeList[index] = updated
            }
        }

        Toast.makeText(this, "Updated", Toast.LENGTH_SHORT).show()
        setResult(Activity.RESULT_OK)
        finish()
    }
}
