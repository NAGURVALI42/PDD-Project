package com.example.myapplication

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.data.ScheduleRepository
import com.example.myapplication.databinding.ActivityTeacherEditScheduleBinding
import com.example.myapplication.models.Schedule
import java.text.SimpleDateFormat
import java.util.*

class TeacherEditScheduleActivity : AppCompatActivity() {

    private lateinit var binding: ActivityTeacherEditScheduleBinding
    private lateinit var currentSchedule: Schedule

    private val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
    private val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
    private var startCalendar = Calendar.getInstance()
    private var endCalendar = Calendar.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTeacherEditScheduleBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        binding.toolbar.setNavigationOnClickListener { finish() }

        // Sample spinner data (replace with actual class names and types)
        val classList = listOf("Class 9-A", "Class 10-A", "Class 10-B")
        val typeList = listOf("Lecture", "Lab", "Exam")

        binding.spinnerClass.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            classList
        )

        binding.spinnerType.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            typeList
        )

        val received = intent.getSerializableExtra("SCHEDULE") as? Schedule
        if (received == null) {
            Toast.makeText(this, "Schedule not found", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        currentSchedule = received
        populateFields()
        setupListeners()
    }

    private fun populateFields() {
        // Subject and notes
        binding.etSubjectName.setText(currentSchedule.subjectName)
        binding.etNotes.setText(currentSchedule.notes)

        // Spinner selections
        setSpinnerSelection(binding.spinnerClass, currentSchedule.className)
        setSpinnerSelection(binding.spinnerType, currentSchedule.scheduleType)

        // Date and Time
        startCalendar.time = currentSchedule.startTime
        endCalendar.time = currentSchedule.endTime

        binding.etScheduleDate.setText(dateFormat.format(currentSchedule.scheduleDate))
        binding.etStartTime.setText(timeFormat.format(startCalendar.time))
        binding.etEndTime.setText(timeFormat.format(endCalendar.time))
    }

    private fun setupListeners() {
        binding.etScheduleDate.setOnClickListener {
            showDatePicker(startCalendar) { selectedDate ->
                binding.etScheduleDate.setText(dateFormat.format(selectedDate.time))
            }
        }

        binding.etStartTime.setOnClickListener {
            showTimePicker(startCalendar) {
                binding.etStartTime.setText(timeFormat.format(it.time))
            }
        }

        binding.etEndTime.setOnClickListener {
            showTimePicker(endCalendar) {
                binding.etEndTime.setText(timeFormat.format(it.time))
            }
        }

        binding.btnSave.setOnClickListener { saveChanges() }
        binding.btnDelete.setOnClickListener { deleteSchedule() }
    }

    private fun showDatePicker(calendar: Calendar, onSelected: (Calendar) -> Unit) {
        DatePickerDialog(
            this,
            { _, year, month, day ->
                calendar.set(year, month, day)
                onSelected(calendar)
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    private fun showTimePicker(calendar: Calendar, onSelected: (Calendar) -> Unit) {
        TimePickerDialog(
            this,
            { _, hour, minute ->
                calendar.set(Calendar.HOUR_OF_DAY, hour)
                calendar.set(Calendar.MINUTE, minute)
                onSelected(calendar)
            },
            calendar.get(Calendar.HOUR_OF_DAY),
            calendar.get(Calendar.MINUTE),
            true
        ).show()
    }

    private fun saveChanges() {
        val updated = currentSchedule.copy(
            className = binding.spinnerClass.selectedItem.toString(),
            subjectName = binding.etSubjectName.text.toString().trim(),
            scheduleType = binding.spinnerType.selectedItem.toString(),
            notes = binding.etNotes.text.toString().trim(),
            scheduleDate = startCalendar.time,
            startTime = startCalendar.time,
            endTime = endCalendar.time
        )

        ScheduleRepository.deleteSchedule(currentSchedule.id)
        ScheduleRepository.addSchedule(updated)

        Toast.makeText(this, "Schedule updated", Toast.LENGTH_SHORT).show()
        finish()
    }

    private fun deleteSchedule() {
        ScheduleRepository.deleteSchedule(currentSchedule.id)
        Toast.makeText(this, "Schedule deleted", Toast.LENGTH_SHORT).show()
        finish()
    }

    private fun setSpinnerSelection(spinner: Spinner, value: String) {
        val adapter = spinner.adapter
        for (i in 0 until adapter.count) {
            if (adapter.getItem(i).toString() == value) {
                spinner.setSelection(i)
                break
            }
        }
    }
}
