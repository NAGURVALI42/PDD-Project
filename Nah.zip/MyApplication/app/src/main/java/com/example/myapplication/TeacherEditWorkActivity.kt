package com.example.myapplication

import android.app.Activity
import android.app.DatePickerDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myapplication.adapters.DocumentUploadAdapter
import com.example.myapplication.data.Work
import com.example.myapplication.data.WorkRepository
import com.example.myapplication.databinding.ActivityTeacherEditWorkBinding
import java.text.SimpleDateFormat
import java.util.*

class TeacherEditWorkActivity : AppCompatActivity() {

    private lateinit var binding: ActivityTeacherEditWorkBinding
    private val documentsList = mutableListOf<String>()
    private lateinit var documentAdapter: DocumentUploadAdapter
    private var workId: String? = null
    private var work: Work? = null
    private var assignedDate: Date = Calendar.getInstance().time
    private var dueDate: Date? = null
    private val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())

    private val documentPicker = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let { uri ->
                addDocumentToList(uri)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTeacherEditWorkBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        getWorkData()
        setupDatePickers()
        setupDocumentsList()
        setupUpdateButton()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener {
            finish()
        }

        binding.toolbar.setOnMenuItemClickListener { menuItem ->
            when (menuItem.itemId) {
                R.id.action_delete -> {
                    showDeleteConfirmation()
                    true
                }
                else -> false
            }
        }
    }

    private fun getWorkData() {
        workId = intent.getStringExtra("WORK_ID")
        if (workId == null) {
            Toast.makeText(this, "Error: Work assignment not found", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        work = WorkRepository.getWorkById(workId!!)
        if (work == null) {
            Toast.makeText(this, "Work not found", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        populateUI()
    }

    private fun populateUI() {
        work?.let { work ->
            binding.etTitle.setText(work.title)
            binding.etDescription.setText(work.description)

            assignedDate = work.assignedDate
            binding.etAssignedDate.setText(dateFormat.format(assignedDate))

            dueDate = work.dueDate
            dueDate?.let {
                binding.etDueDate.setText(dateFormat.format(it))
            }

            binding.chipMath.isChecked = work.subjectList.contains("Mathematics")
            binding.chipScience.isChecked = work.subjectList.contains("Science")
            binding.chipEnglish.isChecked = work.subjectList.contains("English")
            binding.chipHistory.isChecked = work.subjectList.contains("History")
            binding.chipGeography.isChecked = work.subjectList.contains("Geography")

            documentsList.clear()
            documentsList.addAll(work.documentUrls)
            documentAdapter.notifyDataSetChanged()
            updateDocumentsVisibility()
        }
    }

    private fun setupDatePickers() {
        binding.tilAssignedDate.setEndIconOnClickListener {
            showDatePickerDialog(true)
        }

        binding.etAssignedDate.setOnClickListener {
            showDatePickerDialog(true)
        }

        binding.tilDueDate.setEndIconOnClickListener {
            showDatePickerDialog(false)
        }

        binding.etDueDate.setOnClickListener {
            showDatePickerDialog(false)
        }
    }

    private fun setupDocumentsList() {
        documentAdapter = DocumentUploadAdapter(
            documentsList,
            onDeleteClick = { position ->
                documentsList.removeAt(position)
                documentAdapter.notifyItemRemoved(position)
                updateDocumentsVisibility()
            }
        )

        binding.rvDocuments.apply {
            layoutManager = LinearLayoutManager(this@TeacherEditWorkActivity)
            adapter = documentAdapter
        }

        binding.btnAddDocument.setOnClickListener {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
                putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                    "application/pdf",
                    "application/msword",
                    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                    "image/*"
                ))
            }
            documentPicker.launch(intent)
        }
    }

    private fun setupUpdateButton() {
        binding.btnUpdate.setOnClickListener {
            if (validateInputs()) {
                updateWorkAssignment()
            }
        }
    }

    private fun showDatePickerDialog(isAssignedDate: Boolean) {
        val calendar = Calendar.getInstance()
        if (isAssignedDate) {
            calendar.time = assignedDate
        } else if (dueDate != null) {
            calendar.time = dueDate!!
        }

        DatePickerDialog(
            this,
            { _, year, month, dayOfMonth ->
                calendar.set(Calendar.YEAR, year)
                calendar.set(Calendar.MONTH, month)
                calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth)

                val selectedDate = calendar.time
                val formattedDate = dateFormat.format(selectedDate)

                if (isAssignedDate) {
                    assignedDate = selectedDate
                    binding.etAssignedDate.setText(formattedDate)
                } else {
                    dueDate = selectedDate
                    binding.etDueDate.setText(formattedDate)
                }
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    private fun addDocumentToList(uri: Uri) {
        documentsList.add(uri.toString())
        documentAdapter.notifyItemInserted(documentsList.size - 1)
        updateDocumentsVisibility()
    }

    private fun updateDocumentsVisibility() {
        binding.rvDocuments.visibility = if (documentsList.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun validateInputs(): Boolean {
        var isValid = true

        if (binding.etTitle.text.isNullOrBlank()) {
            binding.tilTitle.error = "Title is required"
            isValid = false
        } else {
            binding.tilTitle.error = null
        }

        if (binding.etDescription.text.isNullOrBlank()) {
            binding.tilDescription.error = "Description is required"
            isValid = false
        } else {
            binding.tilDescription.error = null
        }

        if (dueDate != null && dueDate!!.before(assignedDate)) {
            binding.tilDueDate.error = "Due date must be after assigned date"
            isValid = false
        } else {
            binding.tilDueDate.error = null
        }

        return isValid
    }

    private fun updateWorkAssignment() {
        val selectedSubjects = mutableListOf<String>()
        if (binding.chipMath.isChecked) selectedSubjects.add("Mathematics")
        if (binding.chipScience.isChecked) selectedSubjects.add("Science")
        if (binding.chipEnglish.isChecked) selectedSubjects.add("English")
        if (binding.chipHistory.isChecked) selectedSubjects.add("History")
        if (binding.chipGeography.isChecked) selectedSubjects.add("Geography")

        val updatedWork = Work(
            id = workId!!,
            title = binding.etTitle.text.toString(),
            description = binding.etDescription.text.toString(),
            assignedDate = assignedDate,
            dueDate = dueDate,
            subjectList = selectedSubjects,
            documentUrls = documentsList
        )

        WorkRepository.updateWork(updatedWork)
        Toast.makeText(this, "Work updated successfully", Toast.LENGTH_SHORT).show()
        finish()
    }

    private fun showDeleteConfirmation() {
        AlertDialog.Builder(this)
            .setTitle("Delete Work Assignment")
            .setMessage("Are you sure you want to delete this work assignment?")
            .setPositiveButton("Delete") { _, _ ->
                deleteWorkAssignment()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun deleteWorkAssignment() {
        WorkRepository.deleteWork(workId!!)
        Toast.makeText(this, "Work deleted", Toast.LENGTH_SHORT).show()
        finish()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}
