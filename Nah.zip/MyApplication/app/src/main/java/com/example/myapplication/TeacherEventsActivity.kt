package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myapplication.adapters.EventAdapter
import com.example.myapplication.data.Event
import com.example.myapplication.data.EventRepository
import com.example.myapplication.databinding.ActivityTeacherEventsBinding
import java.util.*

class TeacherEventsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityTeacherEventsBinding
    private lateinit var upcomingAdapter: EventAdapter
    private lateinit var pastAdapter: EventAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTeacherEventsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupRecyclerViews()
        setupListeners()
    }

    override fun onResume() {
        super.onResume()
        loadEvents()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.apply {
            setDisplayHomeAsUpEnabled(true)
            setDisplayShowHomeEnabled(true)
        }
        binding.toolbar.setNavigationOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }
    }

    private fun setupRecyclerViews() {
        binding.rvUpcomingEvents.layoutManager = LinearLayoutManager(this)
        binding.rvPastEvents.layoutManager = LinearLayoutManager(this)
    }

    private fun setupListeners() {
        binding.fabAddEvent.setOnClickListener {
            startActivity(Intent(this, TeacherAddEventActivity::class.java))
        }
    }

    private fun loadEvents() {
        val allEvents = EventRepository.getAllEvents()
        val currentTime = Date()

        val upcoming: MutableList<Event> = allEvents.filter { it.startDate.after(currentTime) }.toMutableList()
        val past: MutableList<Event> = allEvents.filter { it.startDate.before(currentTime) }.toMutableList()

        upcomingAdapter = EventAdapter(
            events = upcoming,
            onItemClick = { showEventDetail(it) },
            onEditClick = { editEvent(it) },
            onDeleteClick = { deleteEvent(it) },
            onShareClick = { shareEvent(it) }
        )

        pastAdapter = EventAdapter(
            events = past,
            onItemClick = { showEventDetail(it) },
            onEditClick = { editEvent(it) },
            onDeleteClick = { deleteEvent(it) },
            onShareClick = { shareEvent(it) }
        )

        binding.rvUpcomingEvents.adapter = upcomingAdapter
        binding.rvPastEvents.adapter = pastAdapter
    }

    private fun showEventDetail(event: Event) {
        // Optional: Navigate to detail screen
    }

    private fun editEvent(event: Event) {
        val intent = Intent(this, TeacherEditEventActivity::class.java)
        intent.putExtra("EVENT_ID", event.id)
        startActivity(intent)
    }

    private fun deleteEvent(event: Event) {
        EventRepository.deleteEvent(event.id)
        loadEvents() // Refresh
    }

    private fun shareEvent(event: Event) {
        val shareText = "Event: ${event.title}\nDate: ${event.eventDateTimeFormatted}"
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, shareText)
        }
        startActivity(Intent.createChooser(intent, "Share via"))
    }
}
