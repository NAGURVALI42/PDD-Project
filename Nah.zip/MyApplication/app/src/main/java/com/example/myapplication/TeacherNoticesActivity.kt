package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.example.myapplication.adapters.NoticeAdapter
import com.example.myapplication.data.Notice
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.progressindicator.CircularProgressIndicator
import java.util.*

class TeacherNoticesActivity : AppCompatActivity() {

    private lateinit var etSearch: EditText
    private lateinit var recyclerView: RecyclerView
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var tvEmpty: TextView
    private lateinit var progressBar: CircularProgressIndicator
    private lateinit var fabAdd: FloatingActionButton

    companion object {
        val noticeList: MutableList<Notice> = mutableListOf(
            Notice("1", "Holiday", "No class on Monday", Date()),
            Notice("2", "Exam Notice", "Math exam next week", Date()),
            Notice("3", "Assignment", "Submit by Friday", Date())
        )
    }

    private val fullNoticeList: MutableList<Notice> = mutableListOf()
    private lateinit var noticeAdapter: NoticeAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_teacher_notices)

        etSearch = findViewById(R.id.etSearch)
        recyclerView = findViewById(R.id.recyclerView)
        swipeRefresh = findViewById(R.id.swipeRefresh)
        tvEmpty = findViewById(R.id.tvEmpty)
        progressBar = findViewById(R.id.progressBar)
        fabAdd = findViewById(R.id.fabAdd)

        recyclerView.layoutManager = LinearLayoutManager(this)
        setupAdapter()
        setupListeners()
        loadNotices()
    }

    override fun onResume() {
        super.onResume()
        loadNotices()
    }

    private fun setupAdapter() {
        noticeAdapter = NoticeAdapter(
            notices = fullNoticeList,
            isStudent = false,
            onAction = { notice, action ->
                when (action) {
                    NoticeAdapter.NoticeAction.EDIT -> {
                        val intent = Intent(this, TeacherEditNoticeActivity::class.java)
                        intent.putExtra("NOTICE_ID", notice.id)
                        startActivity(intent)
                    }
                    NoticeAdapter.NoticeAction.DELETE -> {
                        fullNoticeList.remove(notice)
                        noticeList.removeIf { it.id == notice.id }
                        noticeAdapter.notifyDataSetChanged()
                        updateEmptyView(fullNoticeList)
                        Toast.makeText(this, "Deleted: ${notice.title}", Toast.LENGTH_SHORT).show()
                    }
                    else -> Unit
                }
            }
        )
        recyclerView.adapter = noticeAdapter
    }

    private fun setupListeners() {
        etSearch.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {}
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                filterNotices(s.toString())
            }
        })

        swipeRefresh.setOnRefreshListener {
            loadNotices()
        }

        fabAdd.setOnClickListener {
            startActivity(Intent(this, TeacherAddNoticeActivity::class.java))
        }
    }

    private fun loadNotices() {
        swipeRefresh.isRefreshing = true
        progressBar.visibility = View.VISIBLE

        fullNoticeList.clear()
        fullNoticeList.addAll(noticeList)

        progressBar.visibility = View.GONE
        swipeRefresh.isRefreshing = false
        noticeAdapter.notifyDataSetChanged()
        updateEmptyView(fullNoticeList)
    }

    private fun filterNotices(query: String) {
        val filtered = fullNoticeList.filter {
            it.title.contains(query, ignoreCase = true) ||
                    it.description.contains(query, ignoreCase = true)
        }
        noticeAdapter.updateList(filtered)
        updateEmptyView(filtered)
    }

    private fun updateEmptyView(list: List<Notice>) {
        tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
    }
}
