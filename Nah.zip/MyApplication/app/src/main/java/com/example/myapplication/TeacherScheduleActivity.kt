package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myapplication.adapters.ScheduleAdapter
import com.example.myapplication.data.ScheduleRepository
import com.example.myapplication.databinding.ActivityTeacherScheduleBinding

class TeacherScheduleActivity : AppCompatActivity() {

    private lateinit var binding: ActivityTeacherScheduleBinding
    private lateinit var scheduleAdapter: ScheduleAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTeacherScheduleBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }

        scheduleAdapter = ScheduleAdapter(
            schedules = ScheduleRepository.getAllSchedules(),
            onDeleteClick = { schedule ->
                ScheduleRepository.deleteSchedule(schedule.id)
                refreshData()
            },
            onItemClick = { schedule ->
                val intent = Intent(this, TeacherEditScheduleActivity::class.java)
                intent.putExtra("SCHEDULE", schedule)
                startActivity(intent)
            },
            isTeacher = true
        )

        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = scheduleAdapter

        binding.fabAddSchedule.setOnClickListener {
            val intent = Intent(this, TeacherAddScheduleActivity::class.java)
            startActivity(intent)
        }
    }

    override fun onResume() {
        super.onResume()
        refreshData()
    }

    private fun refreshData() {
        scheduleAdapter.updateData(ScheduleRepository.getAllSchedules())
    }
}
