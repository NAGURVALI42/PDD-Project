package com.example.myapplication

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.myapplication.databinding.ActivityTeacherSettingsBinding
import org.json.JSONObject

class TeacherSettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityTeacherSettingsBinding
    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var currentUsername: String
    private var isTeacher = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTeacherSettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        currentUsername = intent.getStringExtra("USERNAME") ?: ""

        // Load shared user preferences
        sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE)

        loadUserProfile()
        loadSettings()
        setupListeners()
    }

    private fun loadUserProfile() {
        val usersJson = sharedPreferences.getString("users_json", "{}")
        val users = JSONObject(usersJson ?: "{}")

        if (!users.has(currentUsername)) {
            Toast.makeText(this, "User not found", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        val userData = users.getJSONObject(currentUsername)
        val name = userData.optString("name", "Unknown")
        val email = userData.optString("email", "")
        val role = userData.optString("role", "Student")

        isTeacher = role.equals("Teacher", ignoreCase = true)

        // Set background color based on role
        val primaryColor = if (isTeacher) R.color.teacher_primary else R.color.student_primary
        binding.toolbar.setBackgroundColor(ContextCompat.getColor(this, primaryColor))
        binding.rootLayout.setBackgroundColor(ContextCompat.getColor(this, primaryColor))

        // Set user details
        binding.tvName.text = name
        binding.tvEmail.text = email
        binding.tvRole.text = "$role"

        binding.toolbar.setNavigationOnClickListener {
            finish()
        }

        // App version
        val versionName = packageManager.getPackageInfo(packageName, 0).versionName
        binding.tvVersion.text = "Version $versionName"
    }

    private fun loadSettings() {
        binding.switchNotifications.isChecked =
            sharedPreferences.getBoolean("${currentUsername}_notifications", true)

        binding.switchDarkMode.isChecked =
            sharedPreferences.getBoolean("${currentUsername}_darkmode", false)

        val language = sharedPreferences.getString("${currentUsername}_language", "English")
        binding.tvLanguage.text = language
    }

    private fun setupListeners() {
        binding.btnLogout.setOnClickListener {
            showLogoutConfirmation()
        }

        binding.btnEditProfile.setOnClickListener {
            Toast.makeText(this, "Edit Profile coming soon", Toast.LENGTH_SHORT).show()
        }

        binding.switchNotifications.setOnCheckedChangeListener { _, isChecked ->
            sharedPreferences.edit().putBoolean("${currentUsername}_notifications", isChecked).apply()
        }

        binding.switchDarkMode.setOnCheckedChangeListener { _, isChecked ->
            sharedPreferences.edit().putBoolean("${currentUsername}_darkmode", isChecked).apply()
            Toast.makeText(this, "Restart app to apply dark mode", Toast.LENGTH_SHORT).show()
        }

        binding.layoutLanguage.setOnClickListener {
            showLanguageOptions()
        }

        binding.layoutHelp.setOnClickListener {
            Toast.makeText(this, "Help coming soon", Toast.LENGTH_SHORT).show()
        }

        binding.layoutFeedback.setOnClickListener {
            Toast.makeText(this, "Feedback coming soon", Toast.LENGTH_SHORT).show()
        }

        binding.layoutPrivacyPolicy.setOnClickListener {
            Toast.makeText(this, "Privacy Policy coming soon", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showLanguageOptions() {
        val languages = arrayOf("English", "Hindi", "Spanish", "French", "German")
        val current = binding.tvLanguage.text.toString()
        val currentIndex = languages.indexOf(current)

        AlertDialog.Builder(this)
            .setTitle("Select Language")
            .setSingleChoiceItems(languages, currentIndex) { dialog, which ->
                val selected = languages[which]
                binding.tvLanguage.text = selected
                sharedPreferences.edit().putString("${currentUsername}_language", selected).apply()
                Toast.makeText(this, "Restart app to apply language", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showLogoutConfirmation() {
        AlertDialog.Builder(this)
            .setTitle("Logout")
            .setMessage("Are you sure you want to logout?")
            .setPositiveButton("Logout") { _, _ -> performLogout() }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun performLogout() {
        sharedPreferences.edit()
            .remove("user_id")
            .remove("user_token")
            .remove("is_logged_in")
            .apply()

        val intent = Intent(this, LoginActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }
}
