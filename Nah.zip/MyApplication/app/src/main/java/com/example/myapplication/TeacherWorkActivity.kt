package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myapplication.adapters.WorkAdapter
import com.example.myapplication.data.Work
import com.example.myapplication.databinding.ActivityTeacherWorkBinding
import com.google.android.material.tabs.TabLayout
import java.util.*

class TeacherWorkActivity : AppCompatActivity() {

    private lateinit var binding: ActivityTeacherWorkBinding
    private lateinit var workAdapter: WorkAdapter

    companion object {
        val workList = mutableListOf<Work>() // Shared list
    }

    private val filteredWorkList = mutableListOf<Work>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTeacherWorkBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupRecyclerView()
        setupSearch()
        setupTabLayout()
        setupFab()
    }

    override fun onResume() {
        super.onResume()
        refreshWork()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }
    }

    private fun setupRecyclerView() {
        workAdapter = WorkAdapter(
            filteredWorkList,
            onItemClick = { work -> openWorkDetail(work) },
            onEditClick = { work -> openEditWork(work) },
            onDeleteClick = { work -> showDeleteConfirmation(work) },
            onShareClick = { work -> shareWork(work) },
            onDocumentClick = { documentUrl -> openDocument(documentUrl) }
        )

        binding.recyclerView.apply {
            layoutManager = LinearLayoutManager(this@TeacherWorkActivity)
            adapter = workAdapter
        }

        binding.swipeRefresh.setOnRefreshListener {
            refreshWork()
        }
    }

    private fun setupSearch() {
        binding.etSearch.setOnQueryTextListener(object :
            androidx.appcompat.widget.SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                filterWork(query)
                return true
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                filterWork(newText)
                return true
            }
        })

        binding.ivFilter.setOnClickListener {
            showFilterOptions()
        }
    }

    private fun setupTabLayout() {
        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                when (tab.position) {
                    0 -> filterWorkByStatus("all")
                    1 -> filterWorkByStatus("active")
                    2 -> filterWorkByStatus("completed")
                }
            }

            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })
    }

    private fun setupFab() {
        binding.fabAddWork.setOnClickListener {
            startActivity(Intent(this, TeacherAddWorkActivity::class.java))
        }
    }

    private fun refreshWork() {
        binding.swipeRefresh.isRefreshing = false
        filteredWorkList.clear()
        filteredWorkList.addAll(workList)
        workAdapter.notifyDataSetChanged()
        updateEmptyViewVisibility()
    }

    private fun filterWork(query: String?) {
        if (query.isNullOrEmpty()) {
            filteredWorkList.clear()
            filteredWorkList.addAll(workList)
        } else {
            val searchQuery = query.lowercase()
            filteredWorkList.clear()
            filteredWorkList.addAll(
                workList.filter { work ->
                    work.title.lowercase().contains(searchQuery) ||
                            work.description.lowercase().contains(searchQuery) ||
                            work.subjectList.any { it.lowercase().contains(searchQuery) }
                }
            )
        }

        updateEmptyViewVisibility()
        workAdapter.notifyDataSetChanged()
    }

    private fun filterWorkByStatus(status: String) {
        filteredWorkList.clear()
        val now = Calendar.getInstance().time
        when (status) {
            "active" -> filteredWorkList.addAll(workList.filter { it.dueDate == null || it.dueDate.after(now) })
            "completed" -> filteredWorkList.addAll(workList.filter { it.dueDate != null && it.dueDate.before(now) })
            "all" -> filteredWorkList.addAll(workList)
        }

        updateEmptyViewVisibility()
        workAdapter.notifyDataSetChanged()
    }

    private fun showFilterOptions() {
        val options = arrayOf("All Subjects", "Mathematics", "Science", "English", "History")

        AlertDialog.Builder(this)
            .setTitle("Filter by Subject")
            .setItems(options) { _, which ->
                filteredWorkList.clear()
                if (which == 0) {
                    filteredWorkList.addAll(workList)
                } else {
                    val selectedSubject = options[which]
                    filteredWorkList.addAll(workList.filter {
                        it.subjectList.any { subject ->
                            subject.equals(selectedSubject, ignoreCase = true)
                        }
                    })
                }
                updateEmptyViewVisibility()
                workAdapter.notifyDataSetChanged()
            }
            .show()
    }

    private fun updateEmptyViewVisibility() {
        binding.tvEmpty.visibility = if (filteredWorkList.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun openWorkDetail(work: Work) {
        Toast.makeText(this, "View: ${work.title}", Toast.LENGTH_SHORT).show()
    }

    private fun openEditWork(work: Work) {
        startActivity(Intent(this, TeacherEditWorkActivity::class.java).apply {
            putExtra("WORK_ID", work.id)
        })
    }

    private fun showDeleteConfirmation(work: Work) {
        AlertDialog.Builder(this)
            .setTitle("Delete Work Assignment")
            .setMessage("Are you sure you want to delete this work assignment?")
            .setPositiveButton("Delete") { _, _ -> deleteWork(work) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun deleteWork(work: Work) {
        workList.remove(work)
        filteredWorkList.remove(work)
        workAdapter.notifyDataSetChanged()
        updateEmptyViewVisibility()
        Toast.makeText(this, "Work assignment deleted", Toast.LENGTH_SHORT).show()
    }

    private fun shareWork(work: Work) {
        val shareText = buildString {
            append("${work.title}\n\n")
            append("${work.description}\n\n")
            append("Subjects: ${work.subjectsText}\n")
            append("Due: ${work.dueDateFormatted}\n\n")
            if (work.hasAttachments) {
                append("Attachments:\n")
                work.documentUrls.forEach { append("$it\n") }
            }
        }

        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, work.title)
            putExtra(Intent.EXTRA_TEXT, shareText)
        }
        startActivity(Intent.createChooser(shareIntent, "Share Work Assignment"))
    }

    private fun openDocument(documentUrl: String) {
        Toast.makeText(this, "Opening: $documentUrl", Toast.LENGTH_SHORT).show()
    }
}
