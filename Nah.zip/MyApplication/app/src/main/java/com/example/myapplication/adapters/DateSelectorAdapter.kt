package com.example.myapplication.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.R
import com.example.myapplication.databinding.ItemDateSelectorBinding
import java.text.SimpleDateFormat
import java.util.*

class DateSelectorAdapter(
    private val dates: List<Date>,
    private val dayFormat: SimpleDateFormat,
    private val dateFormat: SimpleDateFormat,
    private val onDateSelected: (Int) -> Unit
) : RecyclerView.Adapter<DateSelectorAdapter.DateViewHolder>() {

    private var selectedPosition = 0
    
    // Map to store dates that have events
    private val datesWithEvents = mutableMapOf<Int, Boolean>()
    
    fun setSelectedPosition(position: Int) {
        val previousSelected = selectedPosition
        selectedPosition = position
        notifyItemChanged(previousSelected)
        notifyItemChanged(selectedPosition)
    }
    
    // Function to mark dates that have events
    fun setEventsForDate(position: Int, hasEvents: Boolean) {
        datesWithEvents[position] = hasEvents
        notifyItemChanged(position)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DateViewHolder {
        val binding = ItemDateSelectorBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return DateViewHolder(binding)
    }

    override fun onBindViewHolder(holder: DateViewHolder, position: Int) {
        holder.bind(dates[position], position == selectedPosition, datesWithEvents[position] == true)
    }

    override fun getItemCount() = dates.size

    inner class DateViewHolder(private val binding: ItemDateSelectorBinding) :
        RecyclerView.ViewHolder(binding.root) {

        init {
            binding.root.setOnClickListener {
                onDateSelected(adapterPosition)
            }
        }

        fun bind(date: Date, isSelected: Boolean, hasEvents: Boolean) {
            val dayOfWeek = dayFormat.format(date).uppercase()
            val dayOfMonth = dateFormat.format(date)
            
            binding.tvDayOfWeek.text = dayOfWeek
            binding.tvDayOfMonth.text = dayOfMonth
            
            // Show event indicator if there are events on this date
            binding.eventDot.visibility = if (hasEvents) View.VISIBLE else View.GONE
            
            // Apply selected state styling
            val context = binding.root.context
            val backgroundResource = if (isSelected) {
                binding.tvDayOfMonth.setTextColor(ContextCompat.getColor(context, R.color.white))
                binding.tvDayOfWeek.setTextColor(ContextCompat.getColor(context, R.color.white))
                R.drawable.circle_date_background
            } else {
                binding.tvDayOfMonth.setTextColor(ContextCompat.getColor(context, R.color.text_primary))
                binding.tvDayOfWeek.setTextColor(ContextCompat.getColor(context, R.color.text_secondary))
                R.drawable.circle_date_unselected
            }
            
            binding.tvDayOfMonth.setBackgroundResource(backgroundResource)
        }
    }
} 