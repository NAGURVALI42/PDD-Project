package com.example.myapplication.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.R
import com.example.myapplication.databinding.ItemDocumentBinding
import java.io.File

class DocumentAdapter(
    private val documentUrls: List<String>,
    private val onDocumentClick: (String) -> Unit
) : RecyclerView.Adapter<DocumentAdapter.DocumentViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DocumentViewHolder {
        val binding = ItemDocumentBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return DocumentViewHolder(binding)
    }

    override fun onBindViewHolder(holder: DocumentViewHolder, position: Int) {
        val documentUrl = documentUrls[position]
        holder.bind(documentUrl)
    }

    override fun getItemCount(): Int = documentUrls.size

    inner class DocumentViewHolder(private val binding: ItemDocumentBinding) : 
        RecyclerView.ViewHolder(binding.root) {
        
        fun bind(documentUrl: String) {
            // Extract filename from URL
            val fileName = getFileNameFromUrl(documentUrl)
            binding.tvDocumentName.text = fileName
            
            // Set document type icon based on file extension
            val fileExtension = getFileExtension(fileName)
            binding.ivDocumentType.setImageResource(
                when (fileExtension.lowercase()) {
                    "pdf" -> R.drawable.ic_pdf
                    "doc", "docx" -> R.drawable.ic_doc
                    "xls", "xlsx" -> R.drawable.ic_excel
                    "ppt", "pptx" -> R.drawable.ic_powerpoint
                    "jpg", "jpeg", "png" -> R.drawable.ic_image
                    else -> R.drawable.ic_document
                }
            )
            
            // Set click listeners
            binding.root.setOnClickListener {
                onDocumentClick(documentUrl)
            }
            
            binding.btnDownload.setOnClickListener {
                onDocumentClick(documentUrl)
            }
            
            binding.btnPreview.setOnClickListener {
                onDocumentClick(documentUrl)
            }
        }
        
        private fun getFileNameFromUrl(url: String): String {
            return url.substringAfterLast('/') 
        }
        
        private fun getFileExtension(fileName: String): String {
            return fileName.substringAfterLast('.', "")
        }
    }
} 