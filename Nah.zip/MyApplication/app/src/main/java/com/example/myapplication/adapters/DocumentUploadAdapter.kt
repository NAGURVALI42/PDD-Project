package com.example.myapplication.adapters

import android.net.Uri
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.R
import com.example.myapplication.databinding.ItemDocumentUploadBinding

class DocumentUploadAdapter(
    private val documentsList: List<String>,
    private val onDeleteClick: (Int) -> Unit
) : RecyclerView.Adapter<DocumentUploadAdapter.DocumentViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DocumentViewHolder {
        val binding = ItemDocumentUploadBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return DocumentViewHolder(binding)
    }

    override fun onBindViewHolder(holder: DocumentViewHolder, position: Int) {
        val documentUrl = documentsList[position]
        holder.bind(documentUrl)
    }

    override fun getItemCount(): Int = documentsList.size

    inner class DocumentViewHolder(private val binding: ItemDocumentUploadBinding) : 
        RecyclerView.ViewHolder(binding.root) {
        
        fun bind(documentUrl: String) {
            val uri = try {
                Uri.parse(documentUrl)
            } catch (e: Exception) {
                null
            }
            
            // Extract filename from URL or URI
            val fileName = uri?.let { getFileNameFromUri(it) } ?: documentUrl.substringAfterLast('/')
            binding.tvFileName.text = fileName
            
            // Set document type icon based on file extension
            val fileExtension = getFileExtension(fileName)
            binding.ivDocumentType.setImageResource(
                when (fileExtension.lowercase()) {
                    "pdf" -> R.drawable.ic_pdf
                    "doc", "docx" -> R.drawable.ic_doc
                    "xls", "xlsx" -> R.drawable.ic_excel
                    "ppt", "pptx" -> R.drawable.ic_powerpoint
                    "jpg", "jpeg", "png" -> R.drawable.ic_image
                    else -> R.drawable.ic_document
                }
            )
            
            // Set delete click listener
            binding.btnDelete.setOnClickListener {
                onDeleteClick(adapterPosition)
            }
        }
        
        private fun getFileNameFromUri(uri: Uri): String {
            return uri.path?.substringAfterLast('/') ?: "Unknown file"
        }
        
        private fun getFileExtension(fileName: String): String {
            return fileName.substringAfterLast('.', "")
        }
    }
} 