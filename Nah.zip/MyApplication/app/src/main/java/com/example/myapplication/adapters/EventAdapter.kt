package com.example.myapplication.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.example.myapplication.R
import com.example.myapplication.data.Event
import com.example.myapplication.databinding.ItemEventBinding

class EventAdapter(
    private var events: MutableList<Event>,
    private val onItemClick: (Event) -> Unit,
    private val onEditClick: ((Event) -> Unit)? = null,
    private val onDeleteClick: ((Event) -> Unit)? = null,
    private val onShareClick: (Event) -> Unit
) : RecyclerView.Adapter<EventAdapter.EventViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EventViewHolder {
        val binding = ItemEventBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return EventViewHolder(binding)
    }

    override fun getItemCount(): Int = events.size

    override fun onBindViewHolder(holder: EventViewHolder, position: Int) {
        holder.bind(events[position])
    }

    inner class EventViewHolder(private val binding: ItemEventBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(event: Event) {
            binding.apply {
                tvEventTitle.text = event.title
                tvEventDateTime.text = event.eventDateTimeFormatted

                // ✅ Only use Elvis if `location` is nullable
                tvEventLocation.text = event.location ?: root.context.getString(R.string.location_tba)

                tvEventDescription.text = event.description

                // Load image or placeholder
                if (!event.coverImageUrl.isNullOrEmpty()) {
                    Glide.with(root)
                        .load(event.coverImageUrl)
                        .centerCrop()
                        .transition(DrawableTransitionOptions.withCrossFade())
                        .error(R.drawable.ic_image_placeholder)
                        .into(ivEventCover)
                } else {
                    ivEventCover.setImageResource(R.drawable.ic_image_placeholder)
                }

                // Set click listeners
                cardEvent.setOnClickListener { onItemClick(event) }
                btnEdit.setOnClickListener { onEditClick?.invoke(event) }
                btnDelete.setOnClickListener { onDeleteClick?.invoke(event) }
                btnShare.setOnClickListener { onShareClick(event) }
            }
        }
    }

    // 🔄 Public method to update the list
    fun updateEvents(newEvents: List<Event>) {
        events.clear()
        events.addAll(newEvents)
        notifyDataSetChanged()
    }
}
