package com.example.myapplication.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.myapplication.R
import com.example.myapplication.data.Notice
import com.google.android.material.button.MaterialButton

class NoticeAdapter(
    private var notices: List<Notice>,
    private val isStudent: Boolean,
    private val onAction: (Notice, NoticeAction) -> Unit
) : RecyclerView.Adapter<NoticeAdapter.NoticeViewHolder>() {

    enum class NoticeAction {
        VIEW, EDIT, DELETE, SHARE
    }

    fun updateList(newList: List<Notice>) {
        notices = newList
        notifyDataSetChanged()
    }

    inner class NoticeViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvTitle: TextView = view.findViewById(R.id.tvTitle)
        val tvDesc: TextView = view.findViewById(R.id.tvDescription)
        val tvTimestamp: TextView = view.findViewById(R.id.tvTimestamp)
        val btnEdit: MaterialButton = view.findViewById(R.id.btnEdit)
        val ivCover: ImageView = view.findViewById(R.id.ivCover)
        // You can add btnDelete and btnShare here if needed
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NoticeViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_notice, parent, false)
        return NoticeViewHolder(view)
    }

    override fun onBindViewHolder(holder: NoticeViewHolder, position: Int) {
        val notice = notices[position]
        holder.tvTitle.text = notice.title
        holder.tvDesc.text = notice.description
        holder.tvTimestamp.text = notice.timeAgo

        // Load image using Glide
        if (!notice.coverImageUrl.isNullOrEmpty()) {
            holder.ivCover.visibility = View.VISIBLE
            Glide.with(holder.itemView.context)
                .load(notice.coverImageUrl)
                .placeholder(R.drawable.ic_image_placeholder) // Replace with your placeholder image
                .into(holder.ivCover)
        } else {
            holder.ivCover.visibility = View.GONE
        }

        holder.itemView.setOnClickListener {
            onAction(notice, NoticeAction.VIEW)
        }

        if (isStudent) {
            holder.btnEdit.visibility = View.GONE
        } else {
            holder.btnEdit.visibility = View.VISIBLE
            holder.btnEdit.setOnClickListener {
                onAction(notice, NoticeAction.EDIT)
            }
        }
    }

    override fun getItemCount(): Int = notices.size
}
