package com.example.myapplication.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.R
import com.example.myapplication.models.Schedule

class ScheduleAdapter(
    private var schedules: List<Schedule>,
    private val onDeleteClick: (Schedule) -> Unit,
    private val onItemClick: (Schedule) -> Unit,
    private val isTeacher: Boolean = false
) : RecyclerView.Adapter<ScheduleAdapter.ScheduleViewHolder>() {

    inner class ScheduleViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvSubject: TextView = itemView.findViewById(R.id.tvSubject)
        val tvClass: TextView = itemView.findViewById(R.id.tvClass)
        val tvDay: TextView = itemView.findViewById(R.id.tvDay)
        val tvLocation: TextView = itemView.findViewById(R.id.tvLocation)
        val tvTime: TextView = itemView.findViewById(R.id.tvTime)
        val tvScheduleType: TextView = itemView.findViewById(R.id.tvScheduleType)
        val colorIndicator: View = itemView.findViewById(R.id.colorIndicator)
        val btnDelete: ImageButton = itemView.findViewById(R.id.btnDelete)
        val btnEdit: ImageButton = itemView.findViewById(R.id.btnEdit)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ScheduleViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_schedule, parent, false)
        return ScheduleViewHolder(view)
    }

    override fun getItemCount(): Int = schedules.size

    override fun onBindViewHolder(holder: ScheduleViewHolder, position: Int) {
        val schedule = schedules[position]

        holder.tvSubject.text = schedule.subjectName
        holder.tvClass.text = schedule.className
        holder.tvDay.text = schedule.dayOfWeek
        holder.tvLocation.text = schedule.notes
        holder.tvTime.text = schedule.timeRange
        holder.tvScheduleType.text = schedule.scheduleType

        try {
            holder.colorIndicator.setBackgroundColor(android.graphics.Color.parseColor(schedule.color))
        } catch (e: Exception) {
            holder.colorIndicator.setBackgroundColor(android.graphics.Color.GRAY)
        }

        if (isTeacher) {
            holder.btnDelete.visibility = View.VISIBLE
            holder.btnEdit.visibility = View.VISIBLE

            holder.btnDelete.setOnClickListener { onDeleteClick(schedule) }
            holder.btnEdit.setOnClickListener { onItemClick(schedule) }
        } else {
            holder.btnDelete.visibility = View.GONE
            holder.btnEdit.visibility = View.GONE
        }
    }

    fun updateData(newList: List<Schedule>) {
        this.schedules = newList
        notifyDataSetChanged()
    }
}
