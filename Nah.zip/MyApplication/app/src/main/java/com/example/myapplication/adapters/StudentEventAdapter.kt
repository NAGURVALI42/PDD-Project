package com.example.myapplication.adapters

import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.data.Event
import com.example.myapplication.databinding.ItemStudentEventBinding

class StudentEventAdapter(
    private val events: List<Event>,
    private val onItemClick: (Event) -> Unit,
    private val onShareClick: (Event) -> Unit,
    private val onRemindClick: (Event) -> Unit,
    private val onCalendarClick: (Event) -> Unit
) : RecyclerView.Adapter<StudentEventAdapter.EventViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EventViewHolder {
        val binding = ItemStudentEventBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return EventViewHolder(binding)
    }

    override fun onBindViewHolder(holder: EventViewHolder, position: Int) {
        holder.bind(events[position])
    }

    override fun getItemCount(): Int = events.size

    inner class EventViewHolder(private val binding: ItemStudentEventBinding) :
        RecyclerView.ViewHolder(binding.root) {

        init {
            binding.root.setOnClickListener {
                val position = adapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    onItemClick(events[position])
                }
            }

            binding.btnShare.setOnClickListener {
                val position = adapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    onShareClick(events[position])
                }
            }

            binding.btnRemind.setOnClickListener {
                val position = adapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    onRemindClick(events[position])
                }
            }

            binding.btnCalendar.setOnClickListener {
                val position = adapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    onCalendarClick(events[position])
                }
            }
        }

        fun bind(event: Event) {
            binding.tvEventTitle.text = event.title
            binding.tvEventDescription.text = event.description
            binding.tvEventDateTime.text = event.dateAndTimeDisplay
            binding.tvEventLocation.text = event.location

            // Set the event type indicator color
            try {
                binding.eventTypeIndicator.setBackgroundColor(Color.parseColor(event.color))
            } catch (e: Exception) {
                // Use default color if parsing fails
                binding.eventTypeIndicator.setBackgroundColor(Color.GRAY)
            }

            // Extra logic for past events or other special cases
            if (event.isPast) {
                binding.btnRemind.isEnabled = false
                binding.btnCalendar.isEnabled = false
            } else {
                binding.btnRemind.isEnabled = true
                binding.btnCalendar.isEnabled = true
            }
        }
    }
} 