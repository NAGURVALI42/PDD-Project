package com.example.myapplication.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.example.myapplication.R
import com.example.myapplication.data.Notice
import com.example.myapplication.databinding.ItemStudentNoticeBinding

class StudentNoticeAdapter(
    private val notices: List<Notice>,
    private val onItemClick: (Notice) -> Unit,
    private val onShareClick: (Notice) -> Unit
) : RecyclerView.Adapter<StudentNoticeAdapter.NoticeViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NoticeViewHolder {
        val binding = ItemStudentNoticeBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return NoticeViewHolder(binding)
    }

    override fun onBindViewHolder(holder: NoticeViewHolder, position: Int) {
        val notice = notices[position]
        holder.bind(notice)
    }

    override fun getItemCount(): Int = notices.size

    inner class NoticeViewHolder(private val binding: ItemStudentNoticeBinding) : 
        RecyclerView.ViewHolder(binding.root) {
        
        fun bind(notice: Notice) {
            binding.apply {
                tvTitle.text = notice.title
                tvDescription.text = notice.description
                tvTimestamp.text = "Posted: ${notice.timeAgo}"
                
                if (notice.dueDate != null) {
                    tvDueDate.text = "Due: ${notice.dueDateFormatted}"
                    tvDueDate.visibility = View.VISIBLE
                } else {
                    tvDueDate.visibility = View.GONE
                }
                
                // Show/hide the open link button based on whether there's a URL
                if (notice.linkUrl.isNullOrEmpty()) {
                    btnOpen.visibility = View.GONE
                } else {
                    btnOpen.visibility = View.VISIBLE
                    btnOpen.setOnClickListener {
                        // In a real app, we would open the link in a browser
                        // For now, just trigger the item click to view details
                        onItemClick(notice)
                    }
                }
                
                // Load notice image with Glide
                if (!notice.coverImageUrl.isNullOrEmpty()) {
                    Glide.with(root)
                        .load(notice.coverImageUrl)
                        .centerCrop()
                        .transition(DrawableTransitionOptions.withCrossFade())
                        .error(R.drawable.ic_image_placeholder)
                        .into(ivNoticeCover)
                } else {
                    // Load placeholder image if no cover image URL
                    ivNoticeCover.setImageResource(R.drawable.ic_image_placeholder)
                }
                
                // Set click listeners
                root.setOnClickListener {
                    onItemClick(notice)
                }
                
                btnShare.setOnClickListener {
                    onShareClick(notice)
                }
            }
        }
    }
} 