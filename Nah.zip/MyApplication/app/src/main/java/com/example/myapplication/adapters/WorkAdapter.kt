package com.example.myapplication.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.data.Work
import com.example.myapplication.databinding.ItemWorkBinding

class WorkAdapter(
    private val workList: List<Work>,
    private val onItemClick: (Work) -> Unit,
    private val onEditClick: (Work) -> Unit,
    private val onDeleteClick: (Work) -> Unit,
    private val onShareClick: (Work) -> Unit,
    private val onDocumentClick: (String) -> Unit
) : RecyclerView.Adapter<WorkAdapter.WorkViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): WorkViewHolder {
        val binding = ItemWorkBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return WorkViewHolder(binding)
    }

    override fun onBindViewHolder(holder: WorkViewHolder, position: Int) {
        val work = workList[position]
        holder.bind(work)
    }

    override fun getItemCount(): Int = workList.size

    inner class WorkViewHolder(private val binding: ItemWorkBinding) : 
        RecyclerView.ViewHolder(binding.root) {
        
        fun bind(work: Work) {
            binding.apply {
                // Set text fields
                tvTitle.text = work.title
                tvDescription.text = work.description
                tvSubjects.text = work.subjectsText
                tvDueDate.text = "Due: ${work.dueDateFormatted}"
                
                // Show/hide attachments section
                if (work.hasAttachments) {
                    layoutAttachments.visibility = View.VISIBLE
                    
                    // Setup document adapter
                    val documentAdapter = DocumentAdapter(
                        work.documentUrls,
                        onDocumentClick
                    )
                    
                    rvAttachments.layoutManager = LinearLayoutManager(root.context)
                    rvAttachments.adapter = documentAdapter
                } else {
                    layoutAttachments.visibility = View.GONE
                }
                
                // Set click listeners
                root.setOnClickListener {
                    onItemClick(work)
                }
                
                btnEdit.setOnClickListener {
                    onEditClick(work)
                }
                
                btnDelete.setOnClickListener {
                    onDeleteClick(work)
                }
                
                btnShare.setOnClickListener {
                    onShareClick(work)
                }
            }
        }
    }
} 