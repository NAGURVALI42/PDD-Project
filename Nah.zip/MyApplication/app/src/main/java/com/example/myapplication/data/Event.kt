package com.example.myapplication.data

import java.text.SimpleDateFormat
import java.util.*

data class Event(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val description: String,
    val startDate: Date,
    val endDate: Date? = null,
    val location: String = "",
    val eventType: String = "School", // Capitalized for consistent Spinner matching
    val imageUrl: String? = null,
    val createdBy: String = "Teacher"
) {
    // Formatted start date
    val formattedStartDate: String
        get() = SimpleDateFormat("EEEE, MMM dd, yyyy", Locale.getDefault()).format(startDate)

    // Formatted end date (or fallback to start date)
    val formattedEndDate: String
        get() = endDate?.let {
            SimpleDateFormat("EEEE, MMM dd, yyyy", Locale.getDefault()).format(it)
        } ?: formattedStartDate

    // Formatted start time
    val formattedStartTime: String
        get() = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(startDate)

    // Formatted end time (or empty)
    val formattedEndTime: String
        get() = endDate?.let {
            SimpleDateFormat("hh:mm a", Locale.getDefault()).format(it)
        } ?: ""

    // Combined datetime display
    val dateAndTimeDisplay: String
        get() {
            val dateFormat = SimpleDateFormat("EEE, MMM dd", Locale.getDefault())
            val timeFormat = SimpleDateFormat("hh:mm a", Locale.getDefault())
            return if (endDate != null) {
                val sameDay = Calendar.getInstance().apply { time = startDate }.get(Calendar.DAY_OF_YEAR) ==
                        Calendar.getInstance().apply { time = endDate }.get(Calendar.DAY_OF_YEAR)

                if (sameDay) {
                    "${dateFormat.format(startDate)} • ${timeFormat.format(startDate)} - ${timeFormat.format(endDate)}"
                } else {
                    "${dateFormat.format(startDate)} • ${timeFormat.format(startDate)} - " +
                            "${dateFormat.format(endDate)} • ${timeFormat.format(endDate)}"
                }
            } else {
                "${dateFormat.format(startDate)} • ${timeFormat.format(startDate)}"
            }
        }

    // Status indicators
    val isUpcoming: Boolean
        get() = startDate.after(Date())

    val isOngoing: Boolean
        get() = startDate.before(Date()) && (endDate == null || endDate.after(Date()))

    val isPast: Boolean
        get() = (endDate?.before(Date()) == true) || startDate.before(Date()) && endDate == null

    // Color based on event type
    val color: String
        get() = when (eventType.lowercase(Locale.getDefault())) {
            "school" -> "#4CAF50"
            "cultural" -> "#FF9800"
            "sports" -> "#2196F3"
            "holiday" -> "#F44336"
            "exam" -> "#9C27B0"
            else -> "#757575"
        }

    // Aliases for adapter/view bindings
    val eventDateTimeFormatted: String
        get() = dateAndTimeDisplay

    val coverImageUrl: String?
        get() = imageUrl
}
