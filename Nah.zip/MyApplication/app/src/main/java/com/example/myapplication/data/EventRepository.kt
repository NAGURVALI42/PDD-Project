package com.example.myapplication.data

import com.example.myapplication.data.Event

object EventRepository {
    private val _eventList = mutableListOf<Event>()
    val eventList: List<Event> get() = _eventList

    fun addEvent(event: Event) {
        _eventList.add(event)
    }

    fun getEventById(id: String): Event? {
        return _eventList.find { it.id == id }
    }

    fun updateEvent(updatedEvent: Event) {
        val index = _eventList.indexOfFirst { it.id == updatedEvent.id }
        if (index != -1) {
            _eventList[index] = updatedEvent
        }
    }

    fun deleteEvent(id: String) {
        _eventList.removeAll { it.id == id }
    }

    fun getAllEvents(): List<Event> {
        return _eventList.toList()
    }
}
