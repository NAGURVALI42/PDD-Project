package com.example.myapplication.data

import java.text.SimpleDateFormat
import java.util.*

data class Notice(
    val id: String,
    val title: String,
    val description: String,
    val noticeDate: Date,
    val dueDate: Date? = null,
    val coverImageUrl: String? = null,
    val linkUrl: String? = null,
    val status: String = "active"
) {
    val noticeDateFormatted: String
        get() = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(noticeDate)

    val dueDateFormatted: String
        get() = dueDate?.let {
            SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(it)
        } ?: "No due date"

    val timeAgo: String
        get() {
            val now = Date()
            val diff = (now.time - noticeDate.time) / 1000
            val minutes = diff / 60
            val hours = minutes / 60
            val days = hours / 24
            return when {
                diff < 60 -> "Just now"
                minutes < 60 -> "$minutes minutes ago"
                hours < 24 -> "$hours hours ago"
                days < 7 -> "$days days ago"
                else -> noticeDateFormatted
            }
        }
}
