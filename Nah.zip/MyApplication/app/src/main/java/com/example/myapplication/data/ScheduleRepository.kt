package com.example.myapplication.data

import com.example.myapplication.models.Schedule

object ScheduleRepository {
    private val scheduleList = mutableListOf<Schedule>()

    fun getAllSchedules(): List<Schedule> = scheduleList

    fun addSchedule(schedule: Schedule): Boolean {
        scheduleList.add(schedule)
        return true
    }

    fun deleteSchedule(scheduleId: String): Boolean {
        return scheduleList.removeIf { it.id == scheduleId }
    }

    fun updateSchedule(updatedSchedule: Schedule): Boolean {
        val index = scheduleList.indexOfFirst { it.id == updatedSchedule.id }
        return if (index != -1) {
            scheduleList[index] = updatedSchedule
            true
        } else {
            false
        }
    }
}
