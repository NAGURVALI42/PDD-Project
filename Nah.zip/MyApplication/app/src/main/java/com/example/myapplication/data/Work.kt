package com.example.myapplication.data

import java.text.SimpleDateFormat
import java.util.*

data class Work(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val description: String,
    val assignedDate: Date,
    val dueDate: Date? = null,
    val subjectList: List<String> = emptyList(),
    val documentUrls: List<String> = emptyList(),
    val status: String = "active" // active, archived, draft
) {
    val assignedDateFormatted: String
        get() {
            val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
            return dateFormat.format(assignedDate)
        }
    
    val dueDateFormatted: String
        get() {
            return if (dueDate != null) {
                val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
                dateFormat.format(dueDate)
            } else {
                "No due date"
            }
        }
    
    val timeAgo: String
        get() {
            val now = Calendar.getInstance().time
            val seconds = ((now.time - assignedDate.time) / 1000).toInt()
            val minutes = seconds / 60
            val hours = minutes / 60
            val days = hours / 24
            
            return when {
                seconds < 60 -> "Just now"
                minutes < 60 -> "$minutes minutes ago"
                hours < 24 -> "$hours hours ago"
                days < 7 -> "$days days ago"
                else -> assignedDateFormatted
            }
        }
    
    val subjectsText: String
        get() = if (subjectList.isEmpty()) "All subjects" else subjectList.joinToString(", ")
        
    val hasAttachments: Boolean
        get() = documentUrls.isNotEmpty()
} 