package com.example.myapplication.data

object WorkRepository {
    val workList = mutableListOf<Work>()

    fun getWorkById(id: String): Work? {
        return workList.find { it.id == id }
    }

    fun updateWork(updatedWork: Work) {
        val index = workList.indexOfFirst { it.id == updatedWork.id }
        if (index != -1) {
            workList[index] = updatedWork
        }
    }

    fun deleteWork(id: String) {
        workList.removeAll { it.id == id }
    }

    fun addWork(work: Work) {
        workList.add(work)
    }
}
