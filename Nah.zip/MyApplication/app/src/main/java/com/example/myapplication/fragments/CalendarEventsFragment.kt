package com.example.myapplication.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myapplication.adapters.EventAdapter
import com.example.myapplication.data.Event
import com.example.myapplication.databinding.FragmentCalendarEventsBinding
import java.util.*

class CalendarEventsFragment : Fragment() {

    private var _binding: FragmentCalendarEventsBinding? = null
    private val binding get() = _binding!!

    private val events = mutableListOf<Event>()
    private lateinit var adapter: EventAdapter

    companion object {
        fun newInstance() = CalendarEventsFragment()
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentCalendarEventsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Setup RecyclerView
        adapter = EventAdapter(
            events,
            onItemClick = { /* Handle item click */ },
            onEditClick = { /* Handle edit click */ },
            onDeleteClick = { /* Handle delete click */ },
            onShareClick = { /* Handle share click */ }
        )
        binding.rvCalendarEvents.layoutManager = LinearLayoutManager(requireContext())
        binding.rvCalendarEvents.adapter = adapter

        refreshEvents()
    }

    fun refreshEvents() {
        events.clear()
        events.addAll(getSampleEvents())
        adapter.notifyDataSetChanged()
    }

    private fun getSampleEvents(): List<Event> {
        val now = Calendar.getInstance()
        val start = now.time

        now.add(Calendar.HOUR, 2)
        val end = now.time

        return listOf(
            Event(
                title = "Math Revision Class",
                description = "Chapters 1 to 3 will be covered.",
                startDate = start,
                endDate = end,
                location = "Room 101",
                eventType = "school",
                imageUrl = null
            ),
            Event(
                title = "Annual Sports Day",
                description = "Track and field events for all grades.",
                startDate = Date(System.currentTimeMillis() + 86400000), // 1 day later
                endDate = null,
                location = "School Grounds",
                eventType = "sports",
                imageUrl = null
            )
        )
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
