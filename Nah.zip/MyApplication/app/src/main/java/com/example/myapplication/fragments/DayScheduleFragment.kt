package com.example.myapplication.fragments

import android.content.Intent
import android.os.Bundle
import android.view.*
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myapplication.TeacherEditScheduleActivity
import com.example.myapplication.adapters.ScheduleAdapter
import com.example.myapplication.data.ScheduleRepository
import com.example.myapplication.databinding.FragmentDayScheduleBinding
import com.example.myapplication.models.Schedule

class DayScheduleFragment : Fragment() {

    private var dayOfWeek: String? = null
    private var isTeacher: Boolean = false
    private var _binding: FragmentDayScheduleBinding? = null
    private val binding get() = _binding!!

    private lateinit var scheduleAdapter: ScheduleAdapter
    private val schedulesForDay = mutableListOf<Schedule>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dayOfWeek = arguments?.getString(ARG_DAY)
        isTeacher = arguments?.getBoolean(ARG_IS_TEACHER, false) ?: false
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDayScheduleBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        setupRecyclerView()
        loadSchedules()
        binding.swipeRefresh.setOnRefreshListener { loadSchedules() }
    }

    private fun setupRecyclerView() {
        scheduleAdapter = ScheduleAdapter(
            schedules = schedulesForDay,
            onDeleteClick = { schedule ->
                ScheduleRepository.deleteSchedule(schedule.id)
                Toast.makeText(requireContext(), "Schedule deleted", Toast.LENGTH_SHORT).show()
                loadSchedules()
            },
            onItemClick = { schedule ->
                val intent = Intent(requireContext(), TeacherEditScheduleActivity::class.java)
                intent.putExtra("SCHEDULE", schedule)
                startActivity(intent)
            },
            isTeacher = isTeacher
        )
        binding.recyclerView.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerView.adapter = scheduleAdapter
    }

    private fun loadSchedules() {
        binding.swipeRefresh.isRefreshing = true
        val allSchedules = ScheduleRepository.getAllSchedules()
        val filtered = allSchedules.filter { it.dayOfWeek.equals(dayOfWeek, ignoreCase = true) }

        schedulesForDay.clear()
        schedulesForDay.addAll(filtered)
        scheduleAdapter.notifyDataSetChanged()

        binding.swipeRefresh.isRefreshing = false
        binding.tvEmpty.visibility = if (schedulesForDay.isEmpty()) View.VISIBLE else View.GONE
    }

    companion object {
        private const val ARG_DAY = "DAY"
        private const val ARG_IS_TEACHER = "IS_TEACHER"

        fun newInstance(day: String, isTeacher: Boolean): DayScheduleFragment {
            return DayScheduleFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_DAY, day)
                    putBoolean(ARG_IS_TEACHER, isTeacher)
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
