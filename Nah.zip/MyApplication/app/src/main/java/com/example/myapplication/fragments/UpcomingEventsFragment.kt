package com.example.myapplication.fragments

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myapplication.R
import com.example.myapplication.TeacherEditEventActivity
import com.example.myapplication.adapters.EventAdapter
import com.example.myapplication.data.Event
import com.example.myapplication.databinding.FragmentUpcomingEventsBinding
import java.util.*

class UpcomingEventsFragment : Fragment() {

    private var _binding: FragmentUpcomingEventsBinding? = null
    private val binding get() = _binding!!

    private lateinit var eventAdapter: EventAdapter
    private val eventsList = mutableListOf<Event>()
    private val filteredEventsList = mutableListOf<Event>()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentUpcomingEventsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        setupRecyclerView()
        setupSwipeRefresh()
        setupSearch()
        
        // Initial data load
        loadEvents()
    }
    
    private fun setupRecyclerView() {
        eventAdapter = EventAdapter(
            filteredEventsList,
            onItemClick = { event -> openEventDetail(event) },
            onEditClick = { event -> openEditEvent(event) },
            onDeleteClick = { event -> showDeleteConfirmation(event) },
            onShareClick = { event -> shareEvent(event) }
        )
        
        binding.recyclerView.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = eventAdapter
        }
    }
    
    private fun setupSwipeRefresh() {
        binding.swipeRefresh.setColorSchemeResources(R.color.teacher_accent)
        binding.swipeRefresh.setOnRefreshListener {
            loadEvents()
        }
    }
    
    private fun setupSearch() {
        binding.etSearch.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) {
                filterEvents(binding.etSearch.text.toString())
            }
        }
        
        binding.ivSearch.setOnClickListener {
            filterEvents(binding.etSearch.text.toString())
        }
        
        binding.ivFilter.setOnClickListener {
            showFilterOptions()
        }
    }
    
    private fun loadEvents() {
        binding.progressBar.visibility = View.VISIBLE
        
        // In a real app, this would fetch data from a database or API
        // For this demo, we'll use sample data
        val sampleEvents = listOf(
            Event(
                id = UUID.randomUUID().toString(),
                title = "Annual Science Exhibition",
                description = "Join us for an exciting science exhibition featuring projects from all grades. Parents and students are welcome to attend.",
                startDate = Calendar.getInstance().apply { add(Calendar.DAY_OF_MONTH, 5) }.time,
                endDate = Calendar.getInstance().apply { 
                    add(Calendar.DAY_OF_MONTH, 5)
                    set(Calendar.HOUR_OF_DAY, 15)
                    set(Calendar.MINUTE, 0)
                }.time,
                location = "School Auditorium",
                eventType = "school",
                createdBy = "Administrator"
            ),
            Event(
                id = UUID.randomUUID().toString(),
                title = "Parent-Teacher Meeting",
                description = "Semester review meeting for parents to discuss student progress with their teachers.",
                startDate = Calendar.getInstance().apply { 
                    add(Calendar.DAY_OF_MONTH, 10)
                    set(Calendar.HOUR_OF_DAY, 13)
                    set(Calendar.MINUTE, 0)
                }.time,
                endDate = Calendar.getInstance().apply { 
                    add(Calendar.DAY_OF_MONTH, 10)
                    set(Calendar.HOUR_OF_DAY, 17)
                    set(Calendar.MINUTE, 0)
                }.time,
                location = "School Conference Hall",
                eventType = "school"
            ),
            Event(
                id = UUID.randomUUID().toString(),
                title = "Sports Day",
                description = "Annual sports competition featuring track and field events, team sports, and more.",
                startDate = Calendar.getInstance().apply { 
                    add(Calendar.DAY_OF_MONTH, 15)
                    set(Calendar.HOUR_OF_DAY, 9)
                    set(Calendar.MINUTE, 0)
                }.time,
                endDate = Calendar.getInstance().apply { 
                    add(Calendar.DAY_OF_MONTH, 15)
                    set(Calendar.HOUR_OF_DAY, 16)
                    set(Calendar.MINUTE, 0)
                }.time,
                location = "School Sports Complex",
                eventType = "sports"
            ),
            Event(
                id = UUID.randomUUID().toString(),
                title = "Cultural Festival",
                description = "A day of performances, art exhibitions, and cultural activities to celebrate diversity.",
                startDate = Calendar.getInstance().apply { 
                    add(Calendar.DAY_OF_MONTH, 20)
                    set(Calendar.HOUR_OF_DAY, 10)
                    set(Calendar.MINUTE, 30)
                }.time,
                endDate = Calendar.getInstance().apply { 
                    add(Calendar.DAY_OF_MONTH, 20)
                    set(Calendar.HOUR_OF_DAY, 19)
                    set(Calendar.MINUTE, 0)
                }.time,
                location = "School Auditorium",
                eventType = "cultural"
            ),
            Event(
                id = UUID.randomUUID().toString(),
                title = "End of Term Examinations",
                description = "Final examinations for the current term. Please check the schedule for subject-wise timings.",
                startDate = Calendar.getInstance().apply { 
                    add(Calendar.DAY_OF_MONTH, 25)
                    set(Calendar.HOUR_OF_DAY, 9)
                    set(Calendar.MINUTE, 0)
                }.time,
                endDate = Calendar.getInstance().apply { 
                    add(Calendar.DAY_OF_MONTH, 30)
                    set(Calendar.HOUR_OF_DAY, 15)
                    set(Calendar.MINUTE, 0)
                }.time,
                location = "Examination Hall",
                eventType = "exam"
            )
        )
        
        eventsList.clear()
        eventsList.addAll(sampleEvents.filter { it.isUpcoming })
        
        // Filter for upcoming events only
        filteredEventsList.clear()
        filteredEventsList.addAll(eventsList)
        
        updateEmptyViewVisibility()
        eventAdapter.notifyDataSetChanged()
        
        binding.progressBar.visibility = View.GONE
        binding.swipeRefresh.isRefreshing = false
    }
    
    private fun filterEvents(query: String?) {
        if (query.isNullOrBlank()) {
            filteredEventsList.clear()
            filteredEventsList.addAll(eventsList)
        } else {
            val searchQuery = query.lowercase()
            filteredEventsList.clear()
            filteredEventsList.addAll(
                eventsList.filter { event ->
                    event.title.lowercase().contains(searchQuery) ||
                    event.description.lowercase().contains(searchQuery) ||
                    event.location.lowercase().contains(searchQuery)
                }
            )
        }
        
        updateEmptyViewVisibility()
        eventAdapter.notifyDataSetChanged()
    }
    
    private fun showFilterOptions() {
        val options = arrayOf("All Types", "School Events", "Sports Events", "Cultural Events", "Exams")
        
        AlertDialog.Builder(requireContext())
            .setTitle("Filter Events")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> {
                        // All events
                        filteredEventsList.clear()
                        filteredEventsList.addAll(eventsList)
                    }
                    1 -> {
                        // School events
                        filteredEventsList.clear()
                        filteredEventsList.addAll(eventsList.filter { it.eventType.equals("school", ignoreCase = true) })
                    }
                    2 -> {
                        // Sports events
                        filteredEventsList.clear()
                        filteredEventsList.addAll(eventsList.filter { it.eventType.equals("sports", ignoreCase = true) })
                    }
                    3 -> {
                        // Cultural events
                        filteredEventsList.clear()
                        filteredEventsList.addAll(eventsList.filter { it.eventType.equals("cultural", ignoreCase = true) })
                    }
                    4 -> {
                        // Exams
                        filteredEventsList.clear()
                        filteredEventsList.addAll(eventsList.filter { it.eventType.equals("exam", ignoreCase = true) })
                    }
                }
                updateEmptyViewVisibility()
                eventAdapter.notifyDataSetChanged()
            }
            .show()
    }
    
    private fun updateEmptyViewVisibility() {
        if (filteredEventsList.isEmpty()) {
            binding.tvEmpty.visibility = View.VISIBLE
            binding.recyclerView.visibility = View.GONE
        } else {
            binding.tvEmpty.visibility = View.GONE
            binding.recyclerView.visibility = View.VISIBLE
        }
    }
    
    private fun openEventDetail(event: Event) {
        // Open event detail view
        Toast.makeText(requireContext(), "View event: ${event.title}", Toast.LENGTH_SHORT).show()
    }
    
    private fun openEditEvent(event: Event) {
        val intent = Intent(requireContext(), TeacherEditEventActivity::class.java).apply {
            putExtra("EVENT_ID", event.id)
        }
        startActivity(intent)
    }
    
    private fun showDeleteConfirmation(event: Event) {
        AlertDialog.Builder(requireContext())
            .setTitle("Delete Event")
            .setMessage("Are you sure you want to delete this event?")
            .setPositiveButton("Delete") { _, _ ->
                deleteEvent(event)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    
    private fun deleteEvent(event: Event) {
        // In a real app, this would delete from database or API
        eventsList.remove(event)
        filteredEventsList.remove(event)
        eventAdapter.notifyDataSetChanged()
        updateEmptyViewVisibility()
        
        Toast.makeText(requireContext(), "Event deleted", Toast.LENGTH_SHORT).show()
    }
    
    private fun shareEvent(event: Event) {
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, event.title)
            putExtra(Intent.EXTRA_TEXT, "${event.title}\n\n" +
                    "Date: ${event.formattedStartDate}\n" +
                    "Time: ${event.formattedStartTime} ${if (event.endDate != null) "- ${event.formattedEndTime}" else ""}\n" +
                    "Location: ${event.location}\n\n" +
                    "${event.description}")
        }
        startActivity(Intent.createChooser(shareIntent, "Share Event"))
    }
    
    fun refreshEvents() {
        // Refresh data
        loadEvents()
    }
    
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        fun newInstance(): UpcomingEventsFragment {
            return UpcomingEventsFragment()
        }
    }
} 