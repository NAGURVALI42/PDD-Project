package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.databinding.ActivityLoginBinding
import org.json.JSONObject

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnLogin.setOnClickListener {
            val enteredUsername = binding.etUsername.text.toString().trim()
            val enteredPassword = binding.etPassword.text.toString()

            if (enteredUsername.isEmpty()) {
                binding.tilUsername.error = "Username is required"
                return@setOnClickListener
            } else {
                binding.tilUsername.error = null
            }

            if (enteredPassword.isEmpty()) {
                binding.tilPassword.error = "Password is required"
                return@setOnClickListener
            } else {
                binding.tilPassword.error = null
            }

            val sharedPref = getSharedPreferences("UserPrefs", MODE_PRIVATE)
            val usersJson = sharedPref.getString("users_json", null)

            if (usersJson != null) {
                val users = JSONObject(usersJson)

                if (users.has(enteredUsername)) {
                    val user = users.getJSONObject(enteredUsername)
                    val savedPassword = user.getString("password")
                    val role = user.getString("role")

                    if (enteredPassword == savedPassword) {
                        Toast.makeText(this, "Welcome $enteredUsername", Toast.LENGTH_SHORT).show()

                        val dashboardIntent = if (role == "Teacher") {
                            Intent(this, TeacherDashboardActivity::class.java)
                        } else {
                            Intent(this, StudentDashboardActivity::class.java)
                        }

                        dashboardIntent.putExtra("USERNAME", enteredUsername)
                        dashboardIntent.putExtra("USER_ROLE", role)
                        startActivity(dashboardIntent)
                        finish()
                    } else {
                        Toast.makeText(this, "Incorrect password", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Toast.makeText(this, "Username does not exist", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "No users registered", Toast.LENGTH_SHORT).show()
            }
        }

        binding.tvNewUser.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
            finish()
        }
    }
}
