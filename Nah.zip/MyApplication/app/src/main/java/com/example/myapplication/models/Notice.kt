package com.example.myapplication.models

data class Notice(
    val id: String,
    val noticeDate: String,
    val dueDate: String,
    val description: String,
    val linkUrl: String,
    val coverImage: String
) 