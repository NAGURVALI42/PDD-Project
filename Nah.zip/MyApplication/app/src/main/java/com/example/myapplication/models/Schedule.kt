package com.example.myapplication.models

import java.io.Serializable
import java.text.SimpleDateFormat
import java.util.*

data class Schedule(
    val id: String = UUID.randomUUID().toString(),

    val classId: Int,           // ✅ Used for filtering (important)
    val className: String,         // e.g., "Class 10-A"
    val subjectName: String,       // e.g., "Mathematics"
    val scheduleType: String,      // e.g., "regular", "exam", etc.

    val scheduleDate: Date,
    val startTime: Date,
    val endTime: Date,

    val notes: String = "",
    val createdBy: String = "Teacher"
) : Serializable {

    val formattedDate: String
        get() {
            val dateFormat = SimpleDateFormat("EEEE, MMM dd, yyyy", Locale.getDefault())
            return dateFormat.format(scheduleDate)
        }

    val formattedStartTime: String
        get() {
            val timeFormat = SimpleDateFormat("hh:mm a", Locale.getDefault())
            return timeFormat.format(startTime)
        }

    val formattedEndTime: String
        get() {
            val timeFormat = SimpleDateFormat("hh:mm a", Locale.getDefault())
            return timeFormat.format(endTime)
        }

    val timeRange: String
        get() = "$formattedStartTime - $formattedEndTime"

    val dayOfWeek: String
        get() {
            val dayFormat = SimpleDateFormat("EEEE", Locale.getDefault())
            return dayFormat.format(scheduleDate)
        }

    val dayOfMonth: Int
        get() {
            val calendar = Calendar.getInstance()
            calendar.time = scheduleDate
            return calendar.get(Calendar.DAY_OF_MONTH)
        }

    val month: String
        get() {
            val monthFormat = SimpleDateFormat("MMM", Locale.getDefault())
            return monthFormat.format(scheduleDate)
        }

    val isToday: Boolean
        get() {
            val today = Calendar.getInstance()
            val scheduleDay = Calendar.getInstance().apply { time = scheduleDate }

            return today.get(Calendar.YEAR) == scheduleDay.get(Calendar.YEAR) &&
                    today.get(Calendar.DAY_OF_YEAR) == scheduleDay.get(Calendar.DAY_OF_YEAR)
        }

    val isUpcoming: Boolean
        get() = scheduleDate.after(Calendar.getInstance().time)

    val isDayPassed: Boolean
        get() {
            val today = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }

            val scheduleDay = Calendar.getInstance().apply {
                time = scheduleDate
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }

            return scheduleDay.before(today)
        }

    val color: String
        get() = when (scheduleType.lowercase()) {
            "regular" -> "#4CAF50"  // Green
            "exam" -> "#F44336"     // Red
            "holiday" -> "#2196F3"  // Blue
            "activity" -> "#FF9800" // Orange
            "meeting" -> "#9C27B0"  // Purple
            else -> "#757575"       // Gray
        }
}
