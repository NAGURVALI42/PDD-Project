package com.example.myapplication.fragments

import android.os.Bundle
import android.view.*
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myapplication.adapters.EventAdapter
import com.example.myapplication.data.Event
import android.content.Intent
import com.example.myapplication.data.EventRepository
import com.example.myapplication.databinding.FragmentStudentCalendarEventsBinding
import com.example.myapplication.StudentEventsActivity
import java.text.SimpleDateFormat
import java.util.*

class StudentCalendarEventsFragment : Fragment(), StudentEventsActivity.Refreshable {

    private lateinit var binding: FragmentStudentCalendarEventsBinding
    private lateinit var adapter: EventAdapter
    private val dateFormat = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentStudentCalendarEventsBinding.inflate(inflater, container, false)
        setupRecyclerView()
        loadEvents()
        return binding.root
    }

    private fun setupRecyclerView() {
        adapter = EventAdapter(
            events = mutableListOf(),
            onItemClick = { showEventDetail(it) },
            onEditClick = null,
            onDeleteClick = null,
            onShareClick = { shareEvent(it) }
        )
        binding.recyclerView.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerView.adapter = adapter
    }

    private fun loadEvents() {
        val all = EventRepository.getAllEvents().sortedBy { it.startDate }
        adapter.updateEvents(all)
        binding.tvEmpty.visibility = if (all.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun showEventDetail(event: Event) {
        Toast.makeText(requireContext(), "Event: ${event.title}", Toast.LENGTH_SHORT).show()
    }

    private fun shareEvent(event: Event) {
        val text = "Event: ${event.title}\nDate: ${event.eventDateTimeFormatted}"
        val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(android.content.Intent.EXTRA_TEXT, text)
        }
        startActivity(Intent.createChooser(intent, "Share via"))
    }

    override fun refreshEvents() {
        loadEvents()
    }

    companion object {
        fun newInstance() = StudentCalendarEventsFragment()
    }
}
