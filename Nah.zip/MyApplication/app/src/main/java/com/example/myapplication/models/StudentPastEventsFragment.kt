package com.example.myapplication.fragments

import android.content.Intent
import android.os.Bundle
import android.view.*
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myapplication.adapters.EventAdapter
import com.example.myapplication.data.Event
import com.example.myapplication.data.EventRepository
import com.example.myapplication.databinding.FragmentStudentPastEventsBinding
import com.example.myapplication.StudentEventsActivity
import java.util.*

class StudentPastEventsFragment : Fragment(), StudentEventsActivity.Refreshable {

    private lateinit var binding: FragmentStudentPastEventsBinding
    private lateinit var adapter: EventAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentStudentPastEventsBinding.inflate(inflater, container, false)
        setupRecyclerView()
        loadEvents()
        return binding.root
    }

    private fun setupRecyclerView() {
        adapter = EventAdapter(
            events = mutableListOf(),
            onItemClick = { showEventDetail(it) },
            onEditClick = null,
            onDeleteClick = null,
            onShareClick = { shareEvent(it) }
        )
        binding.rvPastEvents.layoutManager = LinearLayoutManager(requireContext())
        binding.rvPastEvents.adapter = adapter
    }

    private fun loadEvents() {
        val now = Date()
        val past = EventRepository.getAllEvents().filter { it.startDate.before(now) }
        adapter.updateEvents(past)
        binding.tvEmptyPast.visibility = if (past.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun showEventDetail(event: Event) {
        Toast.makeText(requireContext(), "Viewing: ${event.title}", Toast.LENGTH_SHORT).show()
    }

    private fun shareEvent(event: Event) {
        val text = "Event: ${event.title}\nDate: ${event.eventDateTimeFormatted}"
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        startActivity(Intent.createChooser(intent, "Share via"))
    }

    override fun refreshEvents() {
        loadEvents()
    }

    companion object {
        fun newInstance() = StudentPastEventsFragment()
    }
}
