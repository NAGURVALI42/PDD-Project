package com.example.myapplication.fragments

import android.content.Intent
import android.os.Bundle
import android.view.*
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myapplication.adapters.EventAdapter
import com.example.myapplication.data.Event
import com.example.myapplication.data.EventRepository
import com.example.myapplication.databinding.FragmentStudentUpcomingEventsBinding
import com.example.myapplication.StudentEventsActivity

class StudentUpcomingEventsFragment : Fragment(), StudentEventsActivity.Refreshable {

    private lateinit var binding: FragmentStudentUpcomingEventsBinding
    private lateinit var adapter: EventAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentStudentUpcomingEventsBinding.inflate(inflater, container, false)
        setupRecyclerView()
        loadEvents()
        return binding.root
    }

    private fun setupRecyclerView() {
        adapter = EventAdapter(
            events = mutableListOf(),
            onItemClick = { showEventDetail(it) },
            onEditClick = null,
            onDeleteClick = null,
            onShareClick = { shareEvent(it) }
        )
        binding.recyclerView.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerView.adapter = adapter
    }

    private fun loadEvents() {
        val now = java.util.Date()
        val upcoming = EventRepository.getAllEvents().filter { it.startDate.after(now) }
        adapter.updateEvents(upcoming)
        binding.tvEmpty.visibility = if (upcoming.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun showEventDetail(event: Event) {
        Toast.makeText(requireContext(), "Viewing: ${event.title}", Toast.LENGTH_SHORT).show()
    }

    private fun shareEvent(event: Event) {
        val text = "Event: ${event.title}\nDate: ${event.eventDateTimeFormatted}"
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        startActivity(Intent.createChooser(intent, "Share via"))
    }

    override fun refreshEvents() {
        loadEvents()
    }

    companion object {
        fun newInstance() = StudentUpcomingEventsFragment()
    }
}
