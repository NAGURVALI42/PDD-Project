package com.example.myapplication.models
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.databinding.TeacherAddEventBinding
import java.util.*

class TeacherAddEventActivity : AppCompatActivity() {

    private lateinit var binding: TeacherAddEventBinding
    private val calendar = Calendar.getInstance()

    private val imagePicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            binding.ivEventCover.setImageURI(uri)
            binding.ivEventCover.visibility = android.view.View.VISIBLE
            binding.layoutAddImage.visibility = android.view.View.GONE
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = TeacherAddEventBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupDatePicker()
        setupTimePickers()
        setupImagePicker()
        setupSaveButton()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        binding.toolbar.setNavigationOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }
    }

    private fun setupImagePicker() {
        binding.layoutAddImage.setOnClickListener {
            imagePicker.launch("image/*")
        }
    }

    private fun setupDatePicker() {
        binding.etEventDate.setOnClickListener {
            val year = calendar.get(Calendar.YEAR)
            val month = calendar.get(Calendar.MONTH)
            val day = calendar.get(Calendar.DAY_OF_MONTH)

            DatePickerDialog(this, { _, selectedYear, selectedMonth, selectedDay ->
                val dateStr = "${selectedDay}/${selectedMonth + 1}/${selectedYear}"
                binding.etEventDate.setText(dateStr)
            }, year, month, day).show()
        }
    }

    private fun setupTimePickers() {
        val timeListener = { setField: (String) -> Unit ->
            val hour = calendar.get(Calendar.HOUR_OF_DAY)
            val minute = calendar.get(Calendar.MINUTE)

            TimePickerDialog(this, { _, h, m ->
                val timeStr = String.format("%02d:%02d", h, m)
                setField(timeStr)
            }, hour, minute, true).show()
        }

        binding.etStartTime.setOnClickListener {
            timeListener { binding.etStartTime.setText(it) }
        }

        binding.etEndTime.setOnClickListener {
            timeListener { binding.etEndTime.setText(it) }
        }
    }

    private fun setupSaveButton() {
        binding.btnSaveEvent.setOnClickListener {
            val name = binding.etEventName.text.toString().trim()
            val description = binding.etDescription.text.toString().trim()
            val date = binding.etEventDate.text.toString().trim()
            val startTime = binding.etStartTime.text.toString().trim()
            val endTime = binding.etEndTime.text.toString().trim()

            if (name.isEmpty() || date.isEmpty() || startTime.isEmpty() || endTime.isEmpty()) {
                Toast.makeText(this, "Please fill in all required fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            Toast.makeText(this, "Event Saved Successfully", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}
